
(function () {
  var splash = document.getElementById("splash");
  var panel = document.getElementById("panel");
  var line = document.getElementById("line");
  var note = document.querySelector(".note");
  var chat = document.getElementById("chat");
  var heartState = document.getElementById("heart-state");
  var eggStatus = document.getElementById("egg-status");
  var tileStatus = document.getElementById("tile-status");
  var SCOUT = "yabowzr://scout";
  var shellPlaceholder = line.getAttribute("placeholder") || "";
  var GREETING = "Hi — I’m RBOT · LOCAL-9SJ1-4JPK. ЯBOWSER side panel ready.";
  var WORDS = { ping: 1, help: 1, status: 1, roster: 1, dossier: 1, edit: 1, "new": 1, clear: 1, hello: 1, hi: 1, home: 1, bot: 1, scout: 1, chalk: 1, chalkboard: 1 };
  var net = document.getElementById("net");
  var online = true;

  function setState(text, kind) {
    [heartState, eggStatus, tileStatus].forEach(function (el) {
      if (!el) return;
      el.textContent = text;
      el.className = (el.id === "heart-state" ? "heart-state " : "tile-status ") + kind;
    });
  }

  function refreshState() {
    Promise.all([
      fetch("/heart").then(function (r) { return r.json(); }),
      fetch("/fuse").then(function (r) { return r.json(); })
    ]).then(function (parts) {
      var alive = !!(parts[0] && parts[0].up);
      var fused = !!(parts[1] && parts[1].fused);
      if (fused && alive) setState("FUSED · HEART ALIVE", "ready");
      else if (fused) setState("FUSED · HEART OFFLINE", "down");
      else if (alive) setState("EGG · HEART ALIVE · NOT UNFURLED", "ready");
      else setState("EGG · HEART OFFLINE", "down");
    }).catch(function () { setState("HEART STATUS UNAVAILABLE", "down"); });
  }
  refreshState();
  window.setInterval(refreshState, 10000);
  net.onclick = function () {
    online = !online;
    net.textContent = online ? "ONLINE" : "OFFLINE";
    net.setAttribute("aria-pressed", online ? "true" : "false");
  };

  function show(which) {
    var on = which === "rbot";
    splash.classList.toggle("on", !on);
    panel.classList.toggle("on", on);
    document.body.classList.toggle("panel-on", on);
    if (on) {
      line.placeholder = SCOUT;
      if (!line.value.trim()) {
        line.value = SCOUT;
        line.dataset.autofill = "1";
      }
    } else {
      line.placeholder = shellPlaceholder;
      if (line.dataset.autofill === "1") {
        line.value = "";
        delete line.dataset.autofill;
      }
    }
  }

  line.addEventListener("input", function () {
    if (line.dataset.autofill === "1" && line.value !== SCOUT) delete line.dataset.autofill;
  });

  var dragon = document.getElementById("dragon");
  var lastToggle = 0;
  function toggleFace() {
    var now = Date.now();
    if (now - lastToggle < 400) return;
    lastToggle = now;
    show(panel.classList.contains("on") ? "shell" : "rbot");
  }
  dragon.onclick = toggleFace;

  function bubble(kind, text) {
    var div = document.createElement("div");
    div.className = "bubble " + kind;
    div.textContent = text;
    chat.appendChild(div);
    scrollChatToLatest();
  }

  function scrollChatToLatest() {
    if (!chat) return;
    var move = function () {
      chat.scrollTop = chat.scrollHeight;
      var last = chat.lastElementChild;
      if (last && last.scrollIntoView) {
        last.scrollIntoView({ block: "end", inline: "nearest" });
      }
    };
    move();
    window.requestAnimationFrame(function () {
      move();
      window.requestAnimationFrame(move);
    });
  }

  if (window.ResizeObserver) {
    new ResizeObserver(scrollChatToLatest).observe(chat);
  }

  function clearChat() {
    chat.textContent = "";
    bubble("bot", GREETING);
  }

  function toggleEdit() {
    var card = document.getElementById("dossier");
    var blurb = document.getElementById("blurb");
    var on = !card.classList.contains("editing");
    card.classList.toggle("editing", on);
    blurb.contentEditable = on ? "true" : "false";
    if (on) blurb.focus();
  }

  function tokenOf(raw) {
    var first = raw.trim().replace(/^\//, "").split(/\s+/)[0] || "";
    return first.toLowerCase().replace(/[^a-z]/g, "");
  }

  function addressOf(raw) {
    var text = (raw || "").trim();
    var low = text.toLowerCase();
    if (!text || /^\{/.test(text)) return null;
    if (/^\/\//.test(text)) return "https:" + text;
    if (/^[a-z][a-z0-9+.-]*:/i.test(text)) return text;
    if (/^(~\/|\/|[a-z]:[\\/])/i.test(text)) return "file://" + text;
    if (/\.[a-z0-9]{1,12}(?:[/?#].*)?$/i.test(text) && !/\s/.test(text)) return text;
    if (/^(localhost|127\.0\.0\.1|0\.0\.0\.0)(:\d+)?(?:\/|$)/i.test(text)) return "http://" + text;
    if (/^(?:\d{1,3}\.){3}\d{1,3}(?::\d+)?(?:\/|$)/.test(text)) return "http://" + text;
    if (/^[^\s/]+\.[a-z]{2,}(?::\d+)?(?:\/|$)/i.test(text)) return "https://" + text;
    if (/^(?:rzl|yabowzr|rbowzr):/i.test(low)) return text;
    return null;
  }

  function commandOf(raw) {
    var text = (raw || "").trim(), body = text.replace(/^\//, ""), match = body.match(/^(\S+)(?:\s+([\s\S]*))?$/);
    if (!match) return null;
    var verb = match[1].toLowerCase(), arg = (match[2] || "").trim();
    if (["hello", "hi", "hey"].indexOf(verb) >= 0) return { verb: "hello", arg: arg };
    if (["home", "bot", "scout", "help", "chalk", "chalkboard", "ping", "status", "roster", "dossier", "edit", "new", "clear"].indexOf(verb) >= 0) return { verb: verb, arg: arg };
    if ((verb === "open" || verb === "go") && arg) return { verb: "open", arg: arg };
    return null;
  }

  function localReply(token) {
    if (token === "ping") return "pong · RBOT · LOCAL-9SJ1-4JPK · local page, no network";
    if (token === "help") return "Smart bar: website/network address, local path, file (.RZL/.json/.html/.pdf), /open or /go <address>, /home, /bot, /scout, HELLO, CHALK/CHALKBOARD, or ordinary conversation. Local words: ping · status · roster · dossier · edit · new · clear.";
    if (token === "status") return (online ? "ONLINE" : "OFFLINE") + " · RBOT · LOCAL-9SJ1-4JPK · read-only · local page";
    if (token === "roster") return "BOTS · 1 · RBOT · ЯBOWSER · LOCAL-9SJ1-4JPK";
    if (token === "dossier") return "RBOT · LOCAL-9SJ1-4JPK · read-only. Your local bot. Your first bot on this Mac or device. Edit it, or add more bots with +.";
    if (token === "new") return "Only RBOT is on this device. + does not add another bot.";
    if (token === "edit") return "Edit is on this page only. Nothing was saved and nothing left the device.";
    if (token === "hello" || token === "hi") return GREETING + " Ask me anything, or use /help for Я OS commands.";
    if (token === "home") return "ЯOS home · ЯBOWZR local shell ready.";
    if (token === "bot" || token === "scout") return "RBOT interface ready. Send a message below or type a question in the smart bar.";
    if (token === "chalk" || token === "chalkboard") return "Я OS " + token.toUpperCase() + " command accepted · local board ready.";
    return "";
  }

  function offlineReply() {
    return "Offline — the local Heart did not answer. This reply stayed on the page. Nothing was fetched from the internet.";
  }

  function deliver(raw, echo) {
    var text = (raw || "").trim();
    if (!text) return;
    if (!panel.classList.contains("on")) show("rbot");
    var command = commandOf(text);
    var address = addressOf(text);
    var token = tokenOf(text);
    if (command && command.verb === "open") address = addressOf(command.arg) || command.arg;
    if (command && command.verb === "hello") { show("rbot"); token = "hello"; }
    if (command && command.verb === "bot" && command.arg) { show("rbot"); text = command.arg; token = ""; }
    if (command && command.verb === "scout") { show("rbot"); token = "scout"; }
    if (command && command.verb === "home") { show("shell"); token = "home"; }
    if (command && (command.verb === "chalk" || command.verb === "chalkboard")) token = command.verb;
    if (WORDS[token]) {
      if (token === "clear") {
        clearChat();
        if (note) note.textContent = "Cleared on this page.";
        return;
      }
      if (token === "edit") toggleEdit();
      if (echo !== false) bubble("user", text);
      var reply = localReply(token);
      bubble("bot", reply);
      if (note) note.textContent = reply;
      return;
    }
    if (address) {
      if (echo !== false) bubble("user", text);
      if (!online && !/^(?:file|content|rzl|yabowzr|rbowzr):/i.test(address)) {
        var held = "OFFLINE — address accepted locally, but no network request was made: " + address;
        bubble("bot", held); if (note) note.textContent = held; return;
      }
      if (!online) {
        var localOnly = "LOCAL address accepted · no network request: " + address;
        bubble("bot", localOnly); if (note) note.textContent = localOnly; return;
      }
      fetch("/open", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: address })
      }).then(function (res) {
        return res.json().then(function (data) { return data || {}; }, function () { return {}; });
      }).then(function (data) {
        var reply = data.reply || data.error || "The lane did not answer.";
        bubble("bot", reply);
        if (note) note.textContent = reply;
      }).catch(function () {
        var reply = "OFFLINE — address accepted locally. Nothing was fetched.";
        bubble("bot", reply);
        if (note) note.textContent = reply;
      });
      return;
    }
    if (!online) {
      if (echo !== false) bubble("user", text);
      var heldTalk = "OFFLINE — this line stayed on the page. The Heart was not asked.";
      bubble("bot", heldTalk);
      if (note) note.textContent = heldTalk;
      return;
    }
    if (echo !== false) bubble("user", text);
    var asked = text;
    fetch("/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: asked })
    }).then(function (res) {
      return res.json().then(function (data) { return data || {}; }, function () { return {}; }).then(function (data) {
        if (data.reply) return data.reply;
        if (data.error) return data.error;
        return offlineReply();
      });
    }).catch(function () {
      return offlineReply();
    }).then(function (reply) {
      bubble("bot", reply);
      if (note) note.textContent = reply;
    });
  }

  document.getElementById("go").onclick = function () { deliver(line.value, true); };
  line.addEventListener("keydown", function (e) {
    if (e.key === "Enter") { e.preventDefault(); deliver(line.value, true); }
  });
  document.getElementById("composer").addEventListener("submit", function (e) {
    e.preventDefault();
    var msg = document.getElementById("msg");
    var text = msg.value;
    msg.value = "";
    deliver(text, true);
  });
  document.getElementById("edit-profile").onclick = function () { deliver("edit", false); };
  document.getElementById("edit-card").onclick = function () { deliver("edit", false); };
  document.getElementById("add-bot").onclick = function () { deliver("new", false); };
  document.getElementById("bot-card").onclick = function () {
    if (!panel.classList.contains("on")) show("rbot");
    document.getElementById("msg").focus();
  };
  Array.prototype.forEach.call(document.querySelectorAll("[data-cmd]"), function (btn) {
    btn.onclick = function () { deliver(btn.getAttribute("data-cmd"), true); };
  });

  var egg = document.getElementById("egg");
  var face = document.getElementById("face-tile");
  var seat = document.getElementById("unfurl");
  var TILE = "assets/tiles/integrated.png";
  var seated = false;
  var gen = 0;

  function reduceMotion() {
    return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }

  function settle() {
    seated = true;
    face.src = TILE;
    face.alt = "Integrated tile";
    egg.hidden = true;
    face.hidden = false;
    seat.classList.remove("unfurling");
    seat.classList.add("seated");
  }

  function unfurl(hold) {
    if (seated) return;
    var id = ++gen;
    face.src = TILE;
    face.alt = "Integrated tile";
    egg.hidden = false;
    face.hidden = false;
    seat.classList.remove("seated", "unfurling");
    void seat.offsetWidth;
    if (reduceMotion()) {
      settle();
      return;
    }
    var finished = false;
    function finish(ev) {
      if (ev && ev.animationName && ev.animationName !== "tile-unfurl") return;
      if (finished || id !== gen) return;
      finished = true;
      settle();
    }
    face.addEventListener("animationend", finish);
    setTimeout(function () {
      if (id !== gen) return;
      seat.classList.add("unfurling");
    }, hold);
    setTimeout(function () { finish(); }, hold + 1200);
  }

  var fusing = false;

  function whenHeart() {
    fetch("/heart").then(function (res) { return res.json(); }).then(function (data) {
      if (!(data && data.up)) {
        setTimeout(whenHeart, 400);
        return;
      }
      if (seated || fusing) return;
      fusing = true;
      fetch("/fuse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{}"
      }).then(function (res) {
        return res.json().then(function (body) {
          return { ok: res.ok, body: body || {} };
        }, function () { return { ok: false, body: {} }; });
      }).then(function (result) {
        if (result.ok && result.body && result.body.fused) {
          refreshState();
          unfurl(520);
          return;
        }
        fusing = false;
        setTimeout(whenHeart, 400);
      }).catch(function () {
        fusing = false;
        setTimeout(whenHeart, 400);
      });
    }).catch(function () { setTimeout(whenHeart, 400); });
  }
  whenHeart();
})();
