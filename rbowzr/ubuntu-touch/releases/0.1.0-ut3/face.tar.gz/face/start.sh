#!/bin/sh
set -eu

ROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"
LOG="/tmp/yabowzr-face.log"

# Content-only auto-update.  It uses Python urllib, stages/verifies first,
# and never changes the native launcher, Heart, permissions, or OS image.
UPDATER="$ROOT/ubuntu-touch/face-update.py"
if [ "${YABOWZR_AUTO_UPDATE:-1}" = "1" ] && [ -x "$UPDATER" ]; then
  if /usr/bin/python3 "$UPDATER" stage >>"$LOG" 2>&1; then
    /usr/bin/python3 "$UPDATER" apply >>"$LOG" 2>&1 || true
  fi
fi

FACE="$ROOT/face"
if [ -d "$FACE/active" ]; then
  FACE="$FACE/active"
fi

if ! /usr/bin/python3 -c 'import socket; s=socket.create_connection(("127.0.0.1",8765),0.4); s.close()' 2>/dev/null; then
  /usr/bin/python3 "$FACE/serve.py" >>"$LOG" 2>&1 &
  i=0
  while [ "$i" -lt 25 ]; do
    if /usr/bin/python3 -c 'import socket; s=socket.create_connection(("127.0.0.1",8765),0.4); s.close()' 2>/dev/null; then
      break
    fi
    i=$((i + 1))
    /bin/sleep 0.2
  done
fi

exec /usr/bin/webapp-container --fullscreen \
  --homepage=http://127.0.0.1:8765/mobile.html \
  '--webappUrlPatterns=http://127.0.0.1:8765/*' \
  --name=ЯBOWZR http://127.0.0.1:8765/mobile.html
