"""Face. Not seated yet.

The Mac app already has two pages: a splash with the egg tile, and a bot panel.
Both bars take a line. This file is the place that line will enter.
It does not draw a window. It only names the handoff.
"""

def on_line(text: str) -> str:
    from between.open import ask
    return ask(text)
