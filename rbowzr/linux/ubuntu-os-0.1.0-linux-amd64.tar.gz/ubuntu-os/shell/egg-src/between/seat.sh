#!/bin/sh
# Seat the Heart that already lives outside this tree. Does not download it.
set -e
HEART=/workspace/HEARTS/Qwen3-0.6B-Q8_0.gguf
test -f "$HEART"
if ! curl -sf http://127.0.0.1:11434/api/tags >/dev/null; then
  echo "Ollama is not running on this machine." >&2
  exit 1
fi
printf 'FROM %s\n' "$HEART" > /workspace/egg-src/heart/Modelfile
ollama create rzl-heart -f /workspace/egg-src/heart/Modelfile
