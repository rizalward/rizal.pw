#!/usr/bin/env python3
"""The in-between. Face sends a line. This asks the seated Heart and returns the reply.

Heart stays outside this tree, at HEARTS/Qwen3-0.6B-Q8_0.gguf, named rzl-heart in Ollama.
Network stays off. Nothing here replaces the host bundle.
"""
import json
import sys
import urllib.request

ENGINE = "rzl-heart"
RUNNER = "http://127.0.0.1:11434/api/generate"


def ask(prompt: str) -> str:
    body = json.dumps({"model": ENGINE, "prompt": prompt, "stream": False}).encode()
    req = urllib.request.Request(RUNNER, data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as resp:
        text = json.load(resp).get("response", "")
    if "</think>" in text:
        text = text.split("</think>", 1)[-1]
    return text.strip()


def main() -> None:
    prompt = " ".join(sys.argv[1:]).strip() or "Say hello in one short sentence."
    print(ask(prompt))


if __name__ == "__main__":
    main()
