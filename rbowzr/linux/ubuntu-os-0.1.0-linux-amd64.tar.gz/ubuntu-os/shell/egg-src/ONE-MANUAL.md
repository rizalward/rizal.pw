# Contents

- Cover  ·  page 1
- Translator  ·  page 1
  - Where I look  ·  page 1
- This computer  ·  page 1
- ЯL🆎 · Full transcript  ·  page 2
  - 1. ABO ledger  ·  page 2
  - 2. Haplogroup naming  ·  page 2
  - 3. Converter and maternal scaffold  ·  page 3
  - 4. The spine  ·  page 3
  - 5. The 11 zones  ·  page 4
  - 6. Left rail  ·  page 4
  - 7. Zegura 2004, pulled  ·  page 5
  - 8. Harvard set, R nodes  ·  page 5
  - 9. Saami  ·  page 6
  - 10. Harvard site  ·  page 6
  - 11. Graphic section files  ·  page 6
- ЯL🆎 Lab manual · graphic section  ·  page 6
  - 1. Transcript  ·  page 7
  - 2. Plate labels  ·  page 7
  - 3. Spine  ·  page 7
  - 4. Key  ·  page 7
  - 5. The 11 zones  ·  page 8
  - 6. Analysis  ·  page 8
  - 7. Founding letters and dates  ·  page 8
  - 8. Zegura, the R count  ·  page 8
  - 9. Left rail, seated calls  ·  page 9
  - 10. Harvard pack  ·  page 9
  - 11. Saami pull  ·  page 9
  - 12. Files  ·  page 9
- Installed packages  ·  page 10

---

# Cover

![Я OPERATING SYSTEM user manual](cover.jpg)

The pages after this cover are the translator. The lab files follow those.

# Translator


When I don't understand something, I read the file that should hold the answer and compare it to what you said. If the words don't match a file, I say so instead of guessing.

Translation here means putting that same text into the egg as Markdown or PDF, not turning the host bundle into source.

Example. You ask where the Heart file is. I don't guess. I open `/workspace/egg-src/heart/WHERE`, and it says the file is `/workspace/HEARTS/Qwen3-0.6B-Q8_0.gguf`. That line is the answer. If that file said something else, I would tell you the file and what it says, not a guess.

## Where I look

On this Linux machine I look in three places.

`/workspace` holds the egg, the Heart, and the Ubuntu prep.

`/home/box/agent-data` holds this chat's agent folder, skills, and settings.

`/opt/sand/sand-host` is the bundled host. I can read it, but it is not a source tree.

If the fact is not in one of those, it is not on this machine.


---

# This computer

A short inventory, not a copy of the disk.

- System: Debian GNU/Linux 13 (trixie)
- Kernel: Linux 6.12.94+, x86_64
- Disk: 126 GB total, 2.1 GB used, 118 GB free

Space by folder:

- /usr: 3.6 GB
- /opt: 544 MB
- /workspace: 313 MB
- /var: 184 MB
- /home: 108 MB


<!-- page 2 -->

Installed packages: 1,022 Debian packages.

My own profile and settings: about 112 KB.

---

# ЯL🆎 · Full transcript

Lab session record. Editable markdown. A group label is not a tribe. A haplogroup string is not an address. Counts below are the ones that were seated. They are not a new measurement.

Poster line used in the graphic section: 701,472 Xalelles · 11 zones · 680 Foundation · 10 KAMINOS.

## 1. ABO ledger

The session opened on blood typology. The user asked for a foundational list of tribes found with AB, then a citation with every count, under the mark ЯL🆎.

Seated law: unadmixed Indigenous American series are high O. A is regional, high in Blackfoot, Blood, and Piegan. B and AB are rare or absent. Pasted Mourant 1976 AB tribe counts were not seated as verified headcounts. File: `ABO-AB-foundational-ledger.tsv`.

No living-source filter. The user corrected that rule. Ancient tissue counts were seated.

Three Mourant books, not two:

- 1954, Mourant alone, narrative, xxi+438 pages. Americas ABO in Chapter XIII, pages 136–147. Table 14 America block AB = 0 except Chippewa less-than-half, about 2. Hudson Bay Eskimo n = 67 has 1 A1B. Blackfoot and Blood are 50–60% A genes. B and AB are not printed as headcounts.
- 1958, The ABO Blood Groups, Mourant, Kopec, and Domaniewska-Sobczak. The table book the 1954 volume could not hold.
- 1976, second edition, same three authors, xv+1055 pages, 36 maps. Pasted AB headcounts still not seated as a recovered table.

Ancient tissue, seated as entered. Wyman, Mesa Verde Notes 7(2), August 1937, and Wyman and Boyd 1937, American Anthropologist 39:583–592. Of 226 dried burials (133 Peru, 59 Southwest, 34 Alaska and Aleutian), positives were Peru 1 A, 6 B, 2 AB; Lovelock Cave 1 A; Canyon del Muerto Basket Maker 1 A; Goat Cave, Big Bend, Texas, 1 B.

Also seated: Gilbey and Lubran 1952, 3 A, 2 O, no AB. Hossaini and Allison 1976 Table I: pre-ceramic n = 8, AB = 1; ceramic n = 40, AB about 8; Peruvian colonial n = 45, AB = 1; Chilean colonial n = 18, AB = 0. Llop and Rothhammer 1979: 28 O, 5 undiagnosed, no AB. Candela 1939 Aleut n = 30, counts not recovered.

Living South America, Matson 1966 as quoted: Shipibo n = 142, AB = 0, B 0.70%. Aguaruna n = 151, AB = 0. Piro n = 90, AB = 0. Aymara O-only was seated as a gene statement, not a headcount.

Write-up: `Ancient-American-ABO.md`. Cited counts: `ABO-AB-cited-counts.tsv`. Mourant 1954 extract: `Mourant-1954-Americas-ABO.md` and `ABO-AB-Mourant1954-seated.tsv`.

## 2. Haplogroup naming

User asked for the first citation that turns RFLP haplotypes into haplogroups.

Maternal. Torroni et al. 1993, American Journal of Human Genetics 53:563–590, names A, B, C, D from the RFLP clusters. Precursor lineages, not letters: Schurr et al. 1990, AJHG 46:613–623; Torroni et al. 1992, Genetics 130:153–162.

Paternal. Torroni et al. 1994 classified paternal DNA with probes 49a, 49f, and 12f2. Those are numbered haplotypes, not today’s lettered Y haplogroups. Underhill et al. 1996 finds the American-specific Y marker DYS199, later M3. Y Chromosome Consortium 2002 names it Q3.

The first paper that lists more than one paternal haplogroup in letter form was seated later in the chain: Karafet et al. 1999 still uses numbered haplotypes 1C and 1G. Lell et al. 2002 names M3, M45, and RPS4Y-T. Zegura et al. 2004 prints C, Q, and R.

Founding-date plate:


<!-- page 3 -->

| Year | Line | Named |
|---|---|---|
| 1993 | Maternal | A, B, C, D. Torroni et al. |
| 1994 | Paternal | Numbered 49a, 49f, 12f2 haplotypes. Not letters. |
| 1996 | Paternal | DYS199, later M3. Underhill et al. |
| 1998 | Maternal | X, the first extra. Brown et al., AJHG 63:1852–1861. |
| 1999 | Paternal | 1C and 1G, later C and Q-M3. Karafet et al. |
| 2002 | Paternal | Q3 for M3. Y Chromosome Consortium. |
| 2002 | Paternal | M3, M45, RPS4Y-T. Lell et al. |
| 2004 | Paternal | C, Q, and R. Zegura et al. |

Key. Maternal A, B, C, D, and X. Paternal Q and C. The line “R is not a founder” was removed from the plate text when the user asked. The 2004 row still lists C, Q, and R, because that is what Zegura printed.

## 3. Converter and maternal scaffold

User said the scaffold will take any file with data that can compare, even if it has to learn a new conversion. The converter was built to join locus, chromosome, position, allele, and haplotype to a haplogroup call. File: `uniparental_converter.py`. Tests were reported passed. Registry examples: M3, RPS4Y711, rCRS mitochondrial sites.

The RxC Maternal HaploautoScaffold was built as a maternal autosomal grouping magnetized to the main scaffold, without shifting addresses. File: `maternal_haploauto_scaffold.py`. Host constant: 701,472. Matrix: `maternal-haploauto-RxC.tsv`. Seated sample calls in that matrix included Anzick D, Spirit Cave D, USR2 B.

## 4. The spine

User defined the graphic. The spinal helix is the Ancestry set. Ancient remains and living basal groups with a match get a color on the far right. One pixel or a half pixel magnetizes from the left for 1 or 2 alleles matched.

Exact bed number seated: 701,472 GRCh37 addresses. The raw file is 701,478. The difference is 6 markers. Index 0 is the 680-pin bed. Ten shared runs were measured, 4,155 sites.

Chromosome address space, seated when the user asked how many GRCh37 addresses a full genome has:

- Chromosomes 1–22, X, and Y: 3,095,677,412 addresses. Assembled-molecule length, including N gaps.
- Plus mitochondrial 16,571: 3,095,693,983.
- Primary assembly with unlocalized and unplaced scaffolds: 3,101,788,170.
- Full release with alternate loci and patches: 3,234,834,689. The chip does not use that figure.
- Ancestry v1 reports positions on GRCh37, forward strand. 701,478 markers are about 1 in 4,412 of the chromosomal addresses.

Key, as printed on the plate:

- pin: one of the 680 addresses
- site: chromosome plus position
- snp: one marker at that site
- bp: the GRCh37 coordinate
- run: neighboring shared sites
- bed: the 701,472-address set

Later labels, by user instruction:

- 701,472 Xalelles
- 11 zones

<!-- page 4 -->

- 680 Foundation
- 10 KAMINOS

## 5. The 11 zones

Copied from the spine map. Alleles pulled: 0. The genotype files are not in this folder.

| Zone | Label | Interval | Sites |
|---|---|---|---:|
| 0 | 680 Foundation | pin bed | 680 |
| 1 | KAMINO 1 | chr12:24,661,124–40,285,436 | 581 |
| 2 | KAMINO 2 | chr8:107,791,095–122,506,731 | 457 |
| 3 | KAMINO 3 | chr16:79,357,232–83,270,736 | 402 |
| 4 | KAMINO 4 | chr10:106,039,303–114,139,896 | 401 |
| 5 | KAMINO 5 | chr5:159,284,708–167,919,726 | 397 |
| 6 | KAMINO 6 | chr13:53,503,630–68,180,116 | 395 |
| 7 | KAMINO 7 | chr2:36,520,350–43,371,542 | 394 |
| 8 | KAMINO 8 | chr18:61,587,067–71,069,901 | 392 |
| 9 | KAMINO 9 | chr2:235,043,481–241,231,989 | 385 |
| 10 | KAMINO 10 | chr9:71,769,323–79,201,074 | 351 |

The 10 KAMINOS hold 4,155 sites. With the Foundation, the 11 zones hold 4,835 addresses. File: `eleven-zones.tsv`.

## 6. Left rail

Poster file: `lab-poster-left-rail-haplogroups.html`. Seated calls:

| Site | Maternal | Paternal |
|---|---|---|
| I11974 Los Rieles | C1b | Q1b1a1a1 |
| I1753 Los Rieles | C1b | Q1b1a1a |
| USR1 | C1b | not seated |
| USR2 | B2 | not seated |
| Trail Creek | B2 | not seated |
| Anzick | D4h3a | Q-Z780 |
| Spirit Cave AHUR_2064 | D1 | Q-M848 |
| Spirit Cave AHUR770c | D1 | Q |
| Kennewick | X2a | Q-M3 |
| Shuká Káa | D | male, letter not seated |
| Lovelock 1 | D1 | not seated |
| Lovelock 2 | D1 | not seated |
| Lovelock 3 | B2a1 | not seated |
| Lovelock 4 | D1 | Q1b1b |
| Lapa do Santo 01 | C1d1 | C2a2 |
| Lapa do Santo 05 | A2 | not seated |
| Lapa do Santo 14 | A2 | Q1b1a1a |

<!-- page 5 -->

| Lapa do Santo 15 | A2 | Q1b1a1a1 |
| Lapa do Santo 22 | D4h3a | not seated |
| Lapa do Santo 24 | B2 | Q1b1a2 |
| Lapa do Santo 25 | B2 | not seated |
| Sumidouro 4–8 | D1 or D, not split | Q on 4 of 5 |
| Cuncaicha 15-07, 15-03, 15-04 | not seated | not seated |
| IL2, IL3, IL7 | not seated | not seated |

The first extra maternal is X2a. Kennewick is the only seated X on this rail. The one paternal C is Lapa do Santo 01. Every other seated Y letter on this early rail is Q.

Harvard pack plate, source-stated, not a new call. I2232, Arroyo Seco II, Argentina, about 8,373 years before 1950, paternal R-FGC50227, maternal C1b. I19169, Belize, paternal F, not seated as a founding letter. Kennewick pin count from the called Harvard genotypes, not the raw reads: 79 exact of 166 pins present. Belize Archaic Maya, 24 library rows. Fullest pin row I3442, 192 exact. Thinnest pin row I24541, 0 present. Haplogroup links: 37 rows, beside the map, not addresses.

Living tribal matches: none seated.

Non-Homo sapiens donors listed on the graphic plate, not joined to the bed: Altai, Chagyrskaya 8, Vindija, Vindija G1, Vindija light, Mezmaiskaya 1, Mezmaiskaya 2, Goyet, Les Cottés, Spy, Mandrin 1600, Denisova, Denisova 25, and the mix Denisova 11. The file does not say hybrid. Count on that plate: 11 Neanderthal, 2 Denisovan, 1 mix.

## 7. Zegura 2004, pulled

Zegura, Karafet, Zhivotovsky, and Hammer, Molecular Biology and Evolution 21:164–175, published 1 January 2004.

Abstract, as pulled: SNP analysis indicated that three major haplogroups, denoted as C, Q, and R, accounted for nearly 96% of Native American Y chromosomes. Haplogroups C and Q were deemed to represent early Native American founding Y chromosome lineages; however, most haplogroup R lineages present in Native Americans most likely came from recent admixture with Europeans.

Sample: 588 Native American Y chromosomes, 342 Amerind, 186 Na-Dene, 60 Aleut-Eskimo, inside 2,344 men from 18 Native American, 28 Asian, and 5 European populations. Divergence dates for C and Q against Altai plus North Asians: 10,100 to 17,200 years. They prefer one entry of a polymorphic founding population.

Printed frequencies: Q 76.4%, R 13.4%, C 5.8%. Q-P36* 23.8%, Q-M3 52.6%. C restricted to Tanana 5, Navajo 1, Apache 14, Cheyenne 7, Sioux 5, Wayu 2.

Of 79 R chromosomes, 76 are R-P25. Modal haplotype identical to the European R-P25 modal. Asian modal differs at DYS390 and DYS393. A scaling plot put five of seven Native American R-P25 groups with the Europeans, and none of four Asian groups in that cluster.

The other three are R and not R-P25. Branches typed above P25: R-M207*, derived at M207 and ancestral at M173, and R-M173*, derived at M173 and ancestral at SRY10831b and P25. The paper does not say how the three split, and does not name the men or the populations. The 0.5%, three individuals, unresolved as to ancestry, is that same count. One N-M178 man is described apart from them. European or African admixture is less likely for him. He was 22.7% of their Siberian sample. Left as a rare extra founder or Asian admixture.

Evidence for the “most likely” European reading is the 76. Evidence against treating every R as European is the three unresolved chromosomes, plus the one N-M178.

## 8. Harvard set, R nodes

File counted: AADR v66.p1 compatibility annotation, 23,098 rows. It does not use the 2002 star names.

- 0 rows labeled R-M207* or R-M173*.
- 24 rows ISOGG R, the stand-in for R-M207*. Terminal column says R for 19 of them. One is in the United States, SN-25.SG. Others: Italy, Iran, Bulgaria, Spain, Romania, Serbia, Russia, Germany, China, Estonia, Pakistan, Ukraine, Denmark, France, Uzbekistan, Bangladesh, United Kingdom.
- 50 rows ISOGG R1, the stand-in for R-M173*.
- 3,583 rows start with R, including R1a, R1b, and R2. Those are downstream.

Russia rows that stop at R or R1: 11.

Basal R: I6403, Khvalynsk-2, Saratov. MA1, Mal’ta, Irkutsk.

R1: I6050 Chernoozerye-1, Omsk. I0246 Utyovka-6, Samara. I0942 Kamenny-Ambar-5, Chelyabinsk. TIM008 Timofeyevka, Ivanovo. I20114 Ekaterinovskiy-Mys, Samara. I33306 Zergenta-2, Kalmykia. NEO210 Golubaya-Krinitsa, Voronezh. KVH001 Karavaikha, Vologda. KMM038 Komsomolec 1-Marfa, Stavropol.

<!-- page 6 -->


No basal R or R1 row is labeled Sami, Saami, Laplander, or a tribal group. Aleutian rows at Kagamil, Chaluka, and Ship Rock are Q, plus one L. One Sireniki row is a deep R1a, not basal R or R1.

## 9. Saami

Three modern Finland rows in the compatibility annotation. No Laplander label.

| ID | Group | Y | mtDNA | Date |
|---|---|---|---|---|
| Saami.SG | Unknown, Finland | I-BY35422, I1a1b1a4a1a1i~ | U5b1b1a1 | 0 |
| S_Saami-1.DG | Utsjoki | not seated | not seated | 0 |
| S_Saami-2.DG | Utsjoki | N-PH2767, N1a1a1a1a2a1a1~ | not seated | 0 |

Coverage on the 1.15 million autosomal targets: Saami.SG 16.8×, S_Saami-1.DG 45.5×, S_Saami-2.DG 42.3×. Hits on 1240k: 1,099,318; 1,119,750; 1,120,268. Hits on Human Origins: 555,846; 571,240; 571,560.

Run on the 701,472 bed: 0 addresses tested. The bed file is not in this folder, and the genotype packs were not copied here. Compatibility test: Harvard SNP file is 2,142,271 sites on GRCh37, the same build as the spine, a different site list. Overlap not counted. Pulled file is annotation only: `saami-pulled.tsv`. Run note: `saami-scaffold-run.tsv`.

## 10. Harvard site

Mallick and Reich, The Allen Ancient DNA Resource, Harvard Dataverse, doi 10.7910/DVN/FFIDCW, version 14, release v66.p1. Public 1240k annotation file 13994515, 12.8 MB. Visualizer cites v66.0 as 19,119 sequences, 17,634 ancient individuals, up to 6,399 modern.

v66.p1 packs:

| Pack | Samples |
|---|---:|
| 1240K | 23,089 |
| 2M | 23,104 |
| 2M compatibility | 23,098 |
| HO and HO compatibility | 27,594 |

None of these is the 701,472 Xalelles. The 11 zones are not a Harvard table.

## 11. Graphic section files

- `lab-manual-graphic-section.md` and `lab-manual-graphic-section.pdf`. Summary section, 137 lines, 5 PDF pages. Not this transcript.
- `lab-poster-left-rail-haplogroups.html`
- `lab-poster-founding-dates.html`
- `eleven-zones.tsv`
- `lab-graphic-plate-02.html`, `lab-graphic-plate-03.html`, `lab-graphic-plate-04.html`
- Graphics copied for the manual: `manual-graphics/spine-11-zones.jpg`, `helix-R.jpg`, `key.jpg`, `harvard-pack.jpg`

This file is the separate full transcript.

---

# ЯL🆎 Lab manual · graphic section

<!-- page 7 -->


Editable source. Change a number here, then rebuild the PDF from this file. A group label is not a tribe. A haplogroup string is not an address.

Poster line: **701,472 Xalelles · 11 zones · 680 Foundation · 10 KAMINOS.**

## 1. Transcript

This section records the graphic work in order. It is a summary of what was seated, not a claim that alleles were pulled.

1. The spine was declared as 701,472 GRCh37 addresses. That count is the Ancestry v1 bed after six markers are set aside from the 701,478 raw file. The address list is not in this folder.
2. Index 0 was named the 680-pin bed. It is now labeled the 680 Foundation.
3. Ten neighboring shared runs were measured and drawn. They are now labeled the 10 KAMINOS. Together with the Foundation they are the 11 zones.
4. The left rail was seated with published maternal and paternal letters. X2a on Kennewick was marked as the first extra maternal, outside Torroni’s A, B, C, and D.
5. A founding-date plate was drawn: 1993 A B C D, 1994 numbered Y haplotypes, 1996 DYS199, 1998 X, 1999 1C and 1G, 2002 Q3, 2002 M3 M45 RPS4Y, 2004 C Q R.
6. Zegura 2004 was pulled. Of 588 Native American Y chromosomes, R was 79 men. 76 were R-P25. Three were R and not R-P25. The paper left those three unresolved.
7. The Harvard AADR v66.p1 compatibility annotation, 23,098 rows, was counted. No row uses the 2002 names R-M207* or R-M173*. The closest stand-ins are 24 ISOGG R and 50 ISOGG R1.
8. Three Saami files were found: Saami.SG, S_Saami-1.DG, S_Saami-2.DG. No Laplander row exists. None has been joined to the 701,472 bed. Addresses tested: 0.
9. The Harvard site was checked. Packs are 1240K, 2M, 2M compatibility, and HO. None is the 701,472 Xalelles. The 11 zones are not a Harvard table.

## 2. Plate labels

| Label | Number | What it is |
|---|---:|---|
| Xalelles | 701,472 | The GRCh37 address bed. The spine. |
| Zones | 11 | The 680 Foundation plus the 10 KAMINOS. |
| Foundation | 680 | Index 0. The pin bed at the base. |
| KAMINOS | 10 | The ten shared runs. Neighboring shared sites. |

## 3. Spine

![Spine. 701,472 Xalelles. 0 is the 680 Foundation. 10 KAMINOS.](manual-graphics/spine-11-zones.jpg)

Same fallback as before. A run called in all 39 library rows does not exist. Ranks 1–5 match the earlier five. Ranks 6–10 are the next runs under that same rule. The bed is still 701,472.

![Helix with R at the crown and the base.](manual-graphics/helix-R.jpg)

## 4. Key

![Key. pin, site, snp, bp, run, bed.](manual-graphics/key.jpg)

- pin: one of the 680 Foundation addresses
- site: chromosome plus position
- snp: one marker at that site
- bp: the GRCh37 coordinate
- run: one of the 10 KAMINOS
- bed: the 701,472 Xalelles

<!-- page 8 -->


## 5. The 11 zones

| Zone | Label | Interval | Sites | Alleles pulled |
|---|---|---|---:|---:|
| 0 | 680 Foundation | pin bed | 680 | 0 |
| 1 | KAMINO 1 | chr12:24,661,124–40,285,436 | 581 | 0 |
| 2 | KAMINO 2 | chr8:107,791,095–122,506,731 | 457 | 0 |
| 3 | KAMINO 3 | chr16:79,357,232–83,270,736 | 402 | 0 |
| 4 | KAMINO 4 | chr10:106,039,303–114,139,896 | 401 | 0 |
| 5 | KAMINO 5 | chr5:159,284,708–167,919,726 | 397 | 0 |
| 6 | KAMINO 6 | chr13:53,503,630–68,180,116 | 395 | 0 |
| 7 | KAMINO 7 | chr2:36,520,350–43,371,542 | 394 | 0 |
| 8 | KAMINO 8 | chr18:61,587,067–71,069,901 | 392 | 0 |
| 9 | KAMINO 9 | chr2:235,043,481–241,231,989 | 385 | 0 |
| 10 | KAMINO 10 | chr9:71,769,323–79,201,074 | 351 | 0 |

The 10 KAMINOS hold 4,155 sites. With the 680 Foundation, the 11 zones hold 4,835 addresses. That is inside the 701,472 Xalelles, not a second bed.

## 6. Analysis

The spine map is a coordinate drawing. It is not a genotype matrix. The ten runs were measured as neighboring shared sites. The allele column is 0 because the called genotypes that produced the runs were not copied into this folder.

Harvard and the bed are different panels. The compatibility SNP file pulled from Harvard is 2,142,271 GRCh37 sites. The bed is 701,472 Ancestry addresses. Same build, different site list. Overlap was not counted.

On the Harvard Americas plate, one paternal R is seated: I2232, Arroyo Seco II, Argentina, about 8,373 years before 1950, R-FGC50227, maternal C1b. That is a downstream R call on a source-stated label. It is not one of Zegura’s three unresolved R chromosomes, and it is not a pixel on the spine.

## 7. Founding letters and dates

| Year | Line | Named | Paper |
|---|---|---|---|
| 1993 | Maternal | A, B, C, D | Torroni et al. |
| 1994 | Paternal | Numbered 49a, 49f, 12f2 haplotypes | Torroni et al. Not letters yet. |
| 1996 | Paternal | DYS199, later M3 | Underhill et al. |
| 1998 | Maternal | X, the first extra | Brown et al. |
| 1999 | Paternal | 1C and 1G, later C and Q-M3 | Karafet et al. |
| 2002 | Paternal | Q3 for M3 | Y Chromosome Consortium |
| 2002 | Paternal | M3, M45, RPS4Y-T | Lell et al. |
| 2004 | Paternal | C, Q, and R | Zegura et al. |

Maternal key: A, B, C, D, and X. Paternal key: Q and C. On this rail those sit as A2, B2, C1b, C1d1, D1, D4h3a, and X2a. The only seated paternal C on the early left rail is Lapa do Santo 01, C2a2.

## 8. Zegura, the R count

Zegura, Karafet, Zhivotovsky, and Hammer, Molecular Biology and Evolution 21:164–175, 2004. Three haplogroups, C, Q, and R, accounted for nearly 96% of 588 Native American Y chromosomes. C and Q were called founding. Most R was called recent European admixture.


<!-- page 9 -->

Printed frequencies: Q 76.4%, R 13.4%, C 5.8%. Of 79 R chromosomes, 76 are R-P25. Their modal haplotype matches the European R-P25 modal and differs from the Asian modal at DYS390 and DYS393. The other three are R and not R-P25. The branches typed above P25 are R-M207* and R-M173*. The paper does not say how the three split, and it does not name the men. A separate N-M178 man is not one of the three.

## 9. Left rail, seated calls

| Site | Maternal | Paternal |
|---|---|---|
| Los Rieles I11974 | C1b | Q1b1a1a1 |
| Los Rieles I1753 | C1b | Q1b1a1a |
| USR1 | C1b | not seated |
| USR2 | B2 | not seated |
| Trail Creek | B2 | not seated |
| Anzick | D4h3a | Q-Z780 |
| Spirit Cave AHUR_2064 | D1 | Q-M848 |
| Kennewick | X2a | Q-M3 |
| Shuká Káa | D | male, letter not seated |
| Lovelock 4 | B2a1 or D1 | Q1b1b |
| Lapa do Santo 01 | C1d1 | C2a2 |
| Lapa do Santo 14, 15 | A2 | Q |
| Lapa do Santo 24 | B2 | Q1b1a2 |
| I2232 Arroyo Seco II | C1b | R-FGC50227 |
| Cuncaicha 15-07, 15-03, 15-04 | not seated | not seated |

## 10. Harvard pack

![Ancient Americas, Harvard pack.](manual-graphics/harvard-pack.jpg)

Y and mtDNA strings on that plate are source-stated labels from the AADR v66.p1 annotation, not calls from the 680 Foundation. A blank cell is not seated.

## 11. Saami pull

| ID | Y | mtDNA | Addresses tested |
|---|---|---|---:|
| Saami.SG | I-BY35422 | U5b1b1a1 | 0 |
| S_Saami-1.DG | not seated | not seated | 0 |
| S_Saami-2.DG | N-PH2767 | not seated | 0 |

No Laplander file was in the pack. None of the three is R, R1, or Q.

## 12. Files

- This section: `lab-manual-graphic-section.md`
- PDF: `lab-manual-graphic-section.pdf`
- Zone table: `eleven-zones.tsv`
- Harvard: Reich lab AADR, doi 10.7910/DVN/FFIDCW, v66.p1

---

<!-- page 10 -->


# Installed packages

1022 Debian packages on this computer, with the one-line description each package ships.

| Package | What it is |
| --- | --- |
| `adduser` | add and remove users and groups |
| `adwaita-icon-theme` | default icon theme of GNOME |
| `apt` | commandline package manager |
| `at-spi2-common` | Assistive Technology Service Provider Interface (common files) |
| `bamfdaemon` | Window matching library - daemon |
| `base-files` | Debian base system miscellaneous files |
| `base-passwd` | Debian base system master password and group files |
| `bash` | GNU Bourne Again SHell |
| `binutils` | GNU assembler, linker and binary utilities |
| `binutils-common` | Common files for the GNU assembler, linker and binary utilities |
| `binutils-x86-64-linux-gnu` | GNU binary utilities, for x86-64-linux-gnu target |
| `bsdutils` | basic utilities from 4.4BSD-Lite |
| `bubblewrap` | utility for unprivileged chroot and namespace manipulation |
| `ca-certificates` | Common CA certificates |
| `cargo` | Rust package manager |
| `coinor-libcbc3.1` | Coin-or branch-and-cut mixed integer programming solver (shared libraries) |
| `coinor-libcgl1` | COIN-OR Cut Generation Library |
| `coinor-libclp1` | Coin-or linear programming solver (shared libraries) |
| `coinor-libcoinmp0` | Simple C API for COIN-OR Solvers Clp and Cbc -- library |
| `coinor-libcoinutils3v5` | COIN-OR collection of utility classes (shared libraries) |
| `coinor-libosi1v5` | COIN-OR Open Solver Interface |
| `coreutils` | GNU core utilities |
| `cpp` | GNU C preprocessor (cpp) |
| `cpp-14` | GNU C preprocessor |
| `cpp-14-x86-64-linux-gnu` | GNU C preprocessor for x86_64-linux-gnu |
| `cpp-x86-64-linux-gnu` | GNU C preprocessor (cpp) for the amd64 architecture |
| `curl` | command line tool for transferring data with URL syntax |
| `dash` | POSIX-compliant shell |
| `dbus-bin` | simple interprocess messaging system (command line utilities) |
| `dbus-daemon` | simple interprocess messaging system (reference message bus) |
| `dbus-session-bus-common` | simple interprocess messaging system (session bus configuration) |
| `dbus-x11` | simple interprocess messaging system (X11 deps) |
| `dconf-cli` | simple configuration storage system - utilities |
| `dconf-gsettings-backend` | simple configuration storage system - GSettings back-end |
| `dconf-service` | simple configuration storage system - D-Bus service |
| `debconf` | Debian configuration management system |
| `debian-archive-keyring` | OpenPGP archive certificates of the Debian archive |
| `debianutils` | Miscellaneous utilities specific to Debian |
| `desktop-file-utils` | Utilities for .desktop files |

<!-- page 11 -->

| `diffutils` | File comparison utilities |
| `dirmngr` | GNU privacy guard - network certificate management service |
| `dpkg` | Debian package management system |
| `eslint` | AST-based pattern checker for JavaScript |
| `exo-utils` | Utility files for libexo |
| `ffmpeg` | Tools for transcoding, streaming and playing of multimedia files |
| `findutils` | utilities for finding files--find, xargs |
| `fontconfig` | generic font configuration library - support binaries |
| `fontconfig-config` | generic font configuration library - configuration |
| `fonts-dejavu-core` | Vera font family derivate with additional characters |
| `fonts-dejavu-mono` | Vera font family derivate with additional characters |
| `fonts-liberation` | fonts with the same metrics as Times, Arial and Courier |
| `fonts-noto-cjk` | "No Tofu" font families with large Unicode coverage (CJK regular and bold) |
| `fonts-noto-color-emoji` | color emoji font from Google |
| `fonts-opensymbol` | OpenSymbol TrueType font |
| `fonts-urw-base35` | font set metric-compatible with the 35 PostScript Level 2 Base Fonts |
| `gcc` | GNU C compiler |
| `gcc-14` | GNU C compiler |
| `gcc-14-base` | GCC, the GNU Compiler Collection (base package) |
| `gcc-14-x86-64-linux-gnu` | GNU C compiler for the x86_64-linux-gnu architecture |
| `gcc-x86-64-linux-gnu` | GNU C compiler for the amd64 architecture |
| `gh` | GitHub CLI, GitHub’s official command line tool |
| `git` | fast, scalable, distributed revision control system |
| `git-man` | fast, scalable, distributed revision control system (manual pages) |
| `gnome-themes-extra` | Adwaita GTK 2 theme — engine |
| `gnome-themes-extra-data` | Adwaita GTK 2 theme and Adwaita-dark GTK 3 theme — common files |
| `gnupg` | GNU privacy guard - a free PGP replacement |
| `gnupg-l10n` | GNU privacy guard - localization files |
| `golang-1.24-go` | Go programming language compiler, linker, compiled stdlib |
| `golang-1.24-src` | Go programming language - source files |
| `golang-go` | Go programming language compiler, linker, compiled stdlib |
| `golang-src` | Go programming language - source files |
| `google-chrome-stable` | The web browser from Google |
| `gpg` | GNU Privacy Guard -- minimalist public key operations |
| `gpg-agent` | GNU privacy guard - cryptographic agent |
| `gpgconf` | GNU privacy guard - core configuration utilities |
| `gpgsm` | GNU privacy guard - S/MIME version |
| `grep` | GNU grep, egrep and fgrep |
| `gtk-update-icon-cache` | icon theme caching utility |
| `gtk2-engines-pixbuf` | pixbuf-based theme for GTK 2 |
| `gyp` | Cross-platform build script generator |
| `gzip` | GNU compression utilities |
| `handlebars` | build semantic templates effectively with no frustration |
| `hicolor-icon-theme` | default fallback theme for FreeDesktop.org icon themes |
| `hostname` | utility to set/show the host name or domain name |
| `hsetroot` | tool for composing root-pixmaps for X11 |

<!-- page 12 -->

| `init-system-helpers` | helper tools for all init systems |
| `iproute2` | networking and traffic control tools |
| `iso-codes` | ISO language, territory, currency, script codes and their translations |
| `jq` | lightweight and flexible command-line JSON processor |
| `libabsl20240722` | extensions to the C++ standard library |
| `libabw-0.1-1` | library for reading and writing AbiWord(tm) documents |
| `libacl1` | access control list - shared library |
| `libaom3` | AV1 Video Codec Library |
| `libapparmor1` | changehat AppArmor library |
| `libapt-pkg7.0` | package management runtime library |
| `libargon2-1` | memory-hard hashing function - runtime library |
| `libasan8` | AddressSanitizer -- a fast memory error detector |
| `libasound2-data` | Configuration files and profiles for ALSA drivers |
| `libasound2t64` | shared library for ALSA applications |
| `libass9` | library for SSA/ASS subtitles rendering |
| `libassuan9` | IPC library for the GnuPG components |
| `libasyncns0` | Asynchronous name service query library |
| `libatk-bridge2.0-0t64` | AT-SPI 2 toolkit bridge - shared library |
| `libatk1.0-0t64` | ATK accessibility toolkit |
| `libatomic1` | support library providing __atomic built-in functions |
| `libatspi2.0-0t64` | Assistive Technology Service Provider Interface - shared library |
| `libattr1` | extended attribute handling - shared library |
| `libaudit-common` | Dynamic library for security auditing - common files |
| `libaudit1` | Dynamic library for security auditing |
| `libavahi-client3` | Avahi client library |
| `libavahi-common-data` | Avahi common data files |
| `libavahi-common3` | Avahi common library |
| `libavc1394-0` | control IEEE 1394 audio/video devices |
| `libavcodec61` | FFmpeg library with de/encoders for audio/video codecs - runtime files |
| `libavdevice61` | FFmpeg library for handling input and output devices - runtime files |
| `libavfilter10` | FFmpeg library containing media filters - runtime files |
| `libavformat61` | FFmpeg library with (de)muxers for multimedia containers - runtime files |
| `libavutil59` | FFmpeg library with functions for simplifying programming - runtime files |
| `libbamf3-2t64` | Window matching library - shared library |
| `libbinutils` | GNU binary utilities (private shared library) |
| `libblas3` | Basic Linear Algebra Reference implementations, shared library |
| `libblkid1` | block device ID library |
| `libbluray2` | Blu-ray disc playback support library (shared library) |
| `libboost-iostreams1.83.0` | Boost.Iostreams Library |
| `libboost-locale1.83.0` | C++ facilities for localization |
| `libboost-thread1.83.0` | portable C++ multi-threading |
| `libbox2d2` | 2D physics engine |
| `libbpf1` | eBPF helper library (shared library) |
| `libbrotli1` | library implementing brotli encoder and decoder (shared libraries) |
| `libbs2b0` | Bauer stereophonic-to-binaural DSP library |
| `libbsd0` | utility functions from BSD systems - shared library |

<!-- page 13 -->

| `libbz2-1.0` | high-quality block-sorting file compressor library - runtime |
| `libc-bin` | GNU C Library: Binaries |
| `libc-dev-bin` | GNU C Library: Development binaries |
| `libc6` | GNU C Library: Shared libraries |
| `libc6-dev` | GNU C Library: Development Libraries and Header Files |
| `libcaca0` | colour ASCII art library |
| `libcairo-gobject2` | Cairo 2D vector graphics library (GObject library) |
| `libcairo2` | Cairo 2D vector graphics library |
| `libcap-ng0` | alternate POSIX capabilities library |
| `libcap2` | POSIX 1003.1e capabilities (library) |
| `libcap2-bin` | POSIX 1003.1e capabilities (utilities) |
| `libcares2` | asynchronous name resolver |
| `libcc1-0` | GCC cc1 plugin for GDB |
| `libcdio-cdda2t64` | library to read and control digital audio CDs |
| `libcdio-paranoia2t64` | library to read digital audio CDs with error correction |
| `libcdio19t64` | library to read and control CD-ROM |
| `libcdr-0.1-1` | library for reading and converting Corel DRAW files |
| `libchromaprint1` | audio fingerprint library |
| `libcjson1` | Ultralightweight JSON parser in ANSI C |
| `libcloudproviders0` | cloud provider library |
| `libclucene-contribs1t64` | language specific text analyzers (runtime) |
| `libclucene-core1t64` | core library for full-featured text search engine (runtime) |
| `libcmis-0.6-6t64` | CMIS protocol client library |
| `libcodec2-1.2` | Codec2 runtime library |
| `libcolamd3` | column approximate minimum degree ordering library for sparse matrices |
| `libcolord2` | system service to manage device colour profiles -- runtime |
| `libcom-err2` | common error description library |
| `libconfig11` | parsing/manipulation of structured configuration files |
| `libcrypt-dev` | libcrypt development files |
| `libcrypt1` | libcrypt shared library |
| `libctf-nobfd0` | Compact C Type Format library (runtime, no BFD dependency) |
| `libctf0` | Compact C Type Format library (runtime, BFD dependency) |
| `libcups2t64` | Common UNIX Printing System(tm) - Core library |
| `libcurl3t64-gnutls` | easy-to-use client-side URL transfer library (GnuTLS flavour) |
| `libcurl4t64` | easy-to-use client-side URL transfer library (OpenSSL flavour) |
| `libdatrie1` | Double-array trie library |
| `libdav1d7` | fast and small AV1 video stream decoder (shared library) |
| `libdb5.3t64` | Berkeley v5.3 Database Libraries [runtime] |
| `libdbus-1-3` | simple interprocess messaging system (library) |
| `libdbusmenu-glib4` | library for passing menus over DBus |
| `libdbusmenu-gtk3-4` | library for passing menus over DBus - GTK-3+ version |
| `libdc1394-25` | high level programming interface for IEEE 1394 digital cameras |
| `libdconf1` | simple configuration storage system - runtime library |
| `libde265-0` | Open H.265 video codec implementation |
| `libdebconfclient0` | Debian Configuration Management System (C-implementation library) |
| `libdecor-0-0` | client-side window decoration library |

<!-- page 14 -->

| `libdeflate0` | fast, whole-buffer DEFLATE-based compression and decompression |
| `libdrm-amdgpu1` | Userspace interface to amdgpu-specific kernel DRM services -- runtime |
| `libdrm-common` | Userspace interface to kernel DRM services -- common files |
| `libdrm-intel1` | Userspace interface to intel-specific kernel DRM services -- runtime |
| `libdrm2` | Userspace interface to kernel DRM services -- runtime |
| `libdvdnav4` | DVD navigation library |
| `libdvdread8t64` | library for reading DVDs |
| `libe-book-0.1-1` | library for reading and converting various  e-book formats |
| `libedit2` | BSD editline and history libraries |
| `libelf1t64` | library to read and write ELF files |
| `libeot0` | Library for parsing/converting Embedded OpenType files |
| `libepoxy0` | OpenGL function pointer management library |
| `libepubgen-0.1-1` | EPUB generator library |
| `liberror-perl` | Perl module for error/exception handling in an OO-ish way |
| `libetonyek-0.1-1` | library for reading and converting Apple Keynote presentations |
| `libev4t64` | high-performance event loop library modelled after libevent |
| `libevent-core-2.1-7t64` | Asynchronous event notification library (core) |
| `libexif12` | library to parse EXIF files |
| `libexo-2-0` | Library with extensions for Xfce (GTK-3 version) |
| `libexo-common` | libexo common files |
| `libexpat1` | XML parsing C library - runtime library |
| `libexttextcat-2.0-0` | Language detection library |
| `libexttextcat-data` | Language detection library - data files |
| `libffi8` | Foreign Function Interface library runtime |
| `libfftw3-double3` | Library for computing Fast Fourier Transforms - Double precision |
| `libflac14` | Free Lossless Audio Codec - runtime C library |
| `libflite1` | Small run-time speech synthesis engine - shared libraries |
| `libfontconfig1` | generic font configuration library - runtime |
| `libfontenc1` | X11 font encoding library |
| `libfreehand-0.1-1` | Library for parsing the FreeHand file format structure |
| `libfreetype6` | FreeType 2 font engine, shared library files |
| `libfribidi0` | Free Implementation of the Unicode BiDi algorithm |
| `libgbm1` | generic buffer management API -- runtime |
| `libgcc-14-dev` | GCC support library (development files) |
| `libgcc-s1` | GCC support library |
| `libgcrypt20` | LGPL Crypto library - runtime library |
| `libgdbm-compat4t64` | GNU dbm database routines (legacy support runtime version)  |
| `libgdbm6t64` | GNU dbm database routines (runtime version)  |
| `libgdk-pixbuf-2.0-0` | GDK Pixbuf library |
| `libgdk-pixbuf2.0-common` | GDK Pixbuf library - data files |
| `libgee-0.8-2` | GObject based collection and utility library |
| `libgfortran5` | Runtime library for GNU Fortran applications |
| `libgif7` | library for GIF images (library) |
| `libgit2-1.9` | low-level Git library |
| `libgl1` | Vendor neutral GL dispatch library -- legacy GL support |
| `libgl1-mesa-dri` | free implementation of the OpenGL API -- DRI modules |

<!-- page 15 -->

| `libglib2.0-0t64` | GLib library of C routines |
| `libglvnd0` | Vendor neutral GL dispatch library |
| `libglx-mesa0` | free implementation of the OpenGL API -- GLX vendor library |
| `libglx0` | Vendor neutral GL dispatch library -- GLX support |
| `libgme0` | Playback library for video game music files - shared library |
| `libgmp10` | Multiprecision arithmetic library |
| `libgnome-menu-3-0` | GNOME implementation of the freedesktop menu specification |
| `libgnutls30t64` | GNU TLS library - main runtime library |
| `libgomp1` | GCC OpenMP (GOMP) support library |
| `libgpg-error0` | GnuPG development runtime library |
| `libgpgme11t64` | GPGME - GnuPG Made Easy (library) |
| `libgpgmepp6t64` | C++ wrapper library for GPGME |
| `libgprofng0` | GNU Next Generation profiler (runtime library) |
| `libgraphite2-3` | Font rendering engine for Complex Scripts -- library |
| `libgs-common` | interpreter for the PostScript language and for PDF - ICC profiles |
| `libgs10` | interpreter for the PostScript language and for PDF - Library |
| `libgs10-common` | interpreter for the PostScript language and for PDF - common files |
| `libgsm1` | Shared libraries for GSM speech compressor |
| `libgssapi-krb5-2` | MIT Kerberos runtime libraries - krb5 GSS-API Mechanism |
| `libgstreamer-plugins-base1.0-0` | GStreamer libraries from the "base" set |
| `libgstreamer1.0-0` | Core GStreamer libraries and elements |
| `libgtk-3-0t64` | GTK graphical user interface library |
| `libgtk-3-common` | common files for the GTK graphical user interface library |
| `libgtop-2.0-11` | gtop system monitoring library (shared) |
| `libgtop2-common` | gtop system monitoring library (common) |
| `libgudev-1.0-0` | GObject-based wrapper library for libudev |
| `libharfbuzz-icu0` | OpenType text shaping engine ICU backend |
| `libharfbuzz0b` | OpenType text shaping engine (shared library) |
| `libheif-plugin-dav1d` | HEIF and AVIF file format decoder and encoder - dav1d plugin |
| `libheif-plugin-libde265` | HEIF and AVIF file format decoder and encoder - libde265 plugin |
| `libheif1` | HEIF and AVIF file format decoder and encoder - shared library |
| `libhogweed6t64` | low level cryptographic library (public-key cryptos) |
| `libhttp-parser2.9` | parser for HTTP messages written in C |
| `libhunspell-1.7-0` | spell checker and morphological analyzer (shared library) |
| `libhwasan0` | AddressSanitizer -- a fast memory error detector |
| `libhwy1t64` | Efficient and performance-portable SIMD wrapper (runtime files) |
| `libhyphen0` | ALTLinux hyphenation library - shared library |
| `libice6` | X11 Inter-Client Exchange library |
| `libicu76` | International Components for Unicode |
| `libid3tag0` | ID3 tag reading library from the MAD project |
| `libidn12` | GNU Libidn library, implementation of IETF IDN specifications |
| `libidn2-0` | Internationalized domain names (IDNA2008/TR46) library |
| `libiec61883-0` | partial implementation of IEC 61883 (shared lib) |
| `libijs-0.35` | IJS raster image transport protocol: shared library |
| `libimlib2t64` | image loading, rendering, saving library |
| `libisl23` | manipulating sets and relations of integer points bounded by linear constraints |

<!-- page 16 -->

| `libitm1` | GNU Transactional Memory Library |
| `libjack-jackd2-0` | JACK Audio Connection Kit (libraries) |
| `libjansson4` | C library for encoding, decoding and manipulating JSON data |
| `libjbig0` | JBIGkit libraries |
| `libjbig2dec0` | JBIG2 decoder library - shared libraries |
| `libjemalloc2` | general-purpose scalable concurrent malloc(3) implementation |
| `libjpeg62-turbo` | libjpeg-turbo JPEG runtime library |
| `libjq1` | lightweight and flexible command-line JSON processor - shared library |
| `libjs-events` | Node.js events module for browsers |
| `libjs-inherits` | Browser library that exposes inherits function from Node.js environment |
| `libjs-is-typedarray` | JavaScript library checking if object is TypedArray |
| `libjs-prettify` | syntax highlighting of source code snippets in an html page |
| `libjs-regenerate` | Unicode-aware regular expression generator (JavaScript library) |
| `libjs-source-map` | Mozilla source map generator and consumer - JavaScript library |
| `libjs-sprintf-js` | JavaScript sprintf implementation |
| `libjs-typedarray-to-buffer` | Nodejs utility converting TypedArray to buffer without copy |
| `libjs-util` | JavaScript util module |
| `libjxl0.11` | JPEG XL Image Coding System - "JXL" (shared libraries) |
| `libk5crypto3` | MIT Kerberos runtime libraries - Crypto Library |
| `libkeyutils1` | Linux Key Management Utilities (library) |
| `libkrb5-3` | MIT Kerberos runtime libraries |
| `libkrb5support0` | MIT Kerberos runtime libraries - Support library |
| `libksba8` | X.509 and CMS support library |
| `liblangtag-common` | library to access tags for identifying languages -- data |
| `liblangtag1` | library to access tags for identifying languages |
| `liblapack3` | Library of linear algebra routines 3 - shared version |
| `liblastlog2-2` | lastlog2 database shared library |
| `liblcms2-2` | Little CMS 2 color management library |
| `libldap2` | OpenLDAP libraries |
| `liblerc4` | Limited Error Raster Compression library |
| `liblilv-0-0` | library for simple use of LV2 plugins |
| `libllvm19` | Modular compiler and toolchain technologies, runtime library |
| `liblsan0` | LeakSanitizer -- a memory leak detector (runtime) |
| `libltdl7` | System independent dlopen wrapper for GNU libtool |
| `liblz4-1` | Fast LZ compression algorithm library - runtime |
| `liblzma5` | XZ-format compression library |
| `liblzo2-2` | data compression library |
| `libmbedcrypto16` | lightweight crypto and SSL/TLS library - crypto library |
| `libmbedtls21` | lightweight crypto and SSL/TLS library - tls library |
| `libmbedx509-7` | lightweight crypto and SSL/TLS library - x509 certificate library |
| `libmd0` | message digest functions from BSD systems - shared library |
| `libmhash2` | Library for cryptographic hashing and message authentication |
| `libmnl0` | minimalistic Netlink communication library |
| `libmount1` | device mounting library |
| `libmp3lame0` | MP3 encoding library |
| `libmpc3` | multiple precision complex floating-point library |

<!-- page 17 -->

| `libmpfr6` | multiple precision floating-point computation |
| `libmpg123-0t64` | MPEG layer 1/2/3 audio decoder (shared library) |
| `libmspub-0.1-1` | library for parsing the mspub file structure |
| `libmwaw-0.3-3` | import library for some old Mac text documents |
| `libmysofa1` | library to read HRTFs stored in the AES69-2015 SOFA format |
| `libmythes-1.2-0` | simple thesaurus library |
| `libncursesw6` | shared libraries for terminal handling (wide character support) |
| `libnettle8t64` | low level cryptographic library (symmetric and one-way cryptos) |
| `libnghttp2-14` | library implementing HTTP/2 protocol (shared library) |
| `libnghttp3-9` | HTTP/3 library with QUIC and QPACK (library) |
| `libngtcp2-16` | implementation of QUIC protocol (library) |
| `libngtcp2-crypto-gnutls8` | implementation of QUIC protocol (library) |
| `libnode-dev` | evented I/O for V8 javascript (development files) |
| `libnode115` | evented I/O for V8 javascript - runtime library |
| `libnorm1t64` | NACK-Oriented Reliable Multicast (NORM) library |
| `libnotify4` | sends desktop notifications to a notification daemon |
| `libnpth0t64` | replacement for GNU Pth using system threads |
| `libnspr4` | NetScape Portable Runtime Library |
| `libnss3` | Network Security Service libraries |
| `libnuma1` | Libraries for controlling NUMA policy |
| `libnumbertext-1.0-0` | Number to number name and money text conversion library |
| `libnumbertext-data` | Number to number name and money text conversion library -- data files |
| `libodfgen-0.1-1` | library to generate ODF documents |
| `libogg0` | Ogg bitstream library |
| `libonig5` | regular expressions library |
| `libopenal-data` | Software implementation of the OpenAL audio API (data files) |
| `libopenal1` | Software implementation of the OpenAL audio API (shared library) |
| `libopenjp2-7` | JPEG 2000 image compression/decompression library |
| `libopenmpt0t64` | module music library based on OpenMPT -- shared library |
| `libopus0` | Opus codec runtime library |
| `liborc-0.4-0t64` | Library of Optimized Inner Loops Runtime Compiler |
| `liborcus-0.18-0` | library for processing spreadsheet documents |
| `liborcus-parser-0.18-0` | library for processing spreadsheet documents - parser library |
| `libp11-kit0` | library for loading and coordinating access to PKCS#11 modules - runtime |
| `libpagemaker-0.0-0` | Library for importing and converting PageMaker Documents |
| `libpam-modules` | Pluggable Authentication Modules for PAM |
| `libpam-modules-bin` | Pluggable Authentication Modules for PAM - helper binaries |
| `libpam-runtime` | Runtime support for the PAM library |
| `libpam0g` | Pluggable Authentication Modules library |
| `libpango-1.0-0` | Layout and rendering of internationalized text |
| `libpangocairo-1.0-0` | Layout and rendering of internationalized text |
| `libpangoft2-1.0-0` | Layout and rendering of internationalized text |
| `libpaper2` | Paper sizes catalogue |
| `libpciaccess0` | Generic PCI access library for X |
| `libpcre2-8-0` | New Perl Compatible Regular Expression Library- 8 bit runtime files |
| `libperl5.40` | shared Perl library |

<!-- page 18 -->

| `libpgm-5.3-0t64` | OpenPGM shared library |
| `libpixman-1-0` | pixel-manipulation library for X and cairo |
| `libplacebo349` | GPU-accelerated video/image rendering primitives (shared library) |
| `libplank-common` | Library to build an elegant, simple, clean dock (shared files) |
| `libplank1` | Library to build an elegant, simple, clean dock |
| `libpng16-16t64` | PNG library - runtime (version 1.6) |
| `libpocketsphinx3` | Speech recognition tool - front-end library |
| `libpoppler147` | PDF rendering library |
| `libpostproc58` | FFmpeg library for post processing - runtime files |
| `libproc2-0` | library for accessing process information from /proc |
| `libpsl5t64` | Library for Public Suffix List (shared libraries) |
| `libpulse0` | PulseAudio client libraries |
| `libpython3-stdlib` | interactive high-level object-oriented language (default python3 version) |
| `libpython3.13-minimal` | Minimal subset of the Python language (version 3.13) |
| `libpython3.13-stdlib` | Interactive high-level object-oriented language (standard library, version 3.13) |
| `libquadmath0` | GCC Quad-Precision Math Library |
| `libqxp-0.0-0` | library for reading and converting QuarkXPress files |
| `librabbitmq4` | AMQP client library written in C |
| `libraptor2-0` | Raptor 2 RDF syntax library |
| `librasqal3t64` | Rasqal RDF query library |
| `librav1e0.7` | Fastest and safest AV1 encoder - shared library |
| `libraw1394-11` | library for direct access to IEEE 1394 bus (aka FireWire) |
| `librdf0t64` | Redland Resource Description Framework (RDF) library |
| `libreadline8t64` | GNU readline and history libraries, run-time libraries |
| `libreoffice-base-core` | office productivity suite -- shared library |
| `libreoffice-calc` | office productivity suite -- spreadsheet |
| `libreoffice-common` | office productivity suite -- arch-independent files |
| `libreoffice-core` | office productivity suite -- arch-dependent files |
| `libreoffice-draw` | office productivity suite -- drawing |
| `libreoffice-impress` | office productivity suite -- presentation |
| `libreoffice-style-colibre` | office productivity suite -- colibre symbol style |
| `libreoffice-uiconfig-calc` | UI data ("config") for LibreOffice Calc |
| `libreoffice-uiconfig-common` | UI data ("config") for LibreOffice ("common" set) |
| `libreoffice-uiconfig-draw` | UI data ("config") for LibreOffice Draw |
| `libreoffice-uiconfig-impress` | UI data ("config") for LibreOffice Impress |
| `libreoffice-uiconfig-writer` | UI data ("config") for LibreOffice Writer |
| `libreoffice-writer` | office productivity suite -- word processor |
| `librevenge-0.0-0` | Base Library for writing document interface filters |
| `librist4` | Reliable Internet Stream Transport -- shared library |
| `librsvg2-2` | SAX-based renderer library for SVG files (runtime) |
| `librtmp1` | toolkit for RTMP streams (shared library) |
| `librubberband2` | audio time-stretching and pitch-shifting library |
| `libsamplerate0` | Audio sample rate conversion library |
| `libsasl2-2` | Cyrus SASL - authentication abstraction library |
| `libsasl2-modules-db` | Cyrus SASL - pluggable authentication modules (DB) |
| `libsdl2-2.0-0` | Simple DirectMedia Layer |

<!-- page 19 -->

| `libseccomp2` | high level interface to Linux seccomp filter |
| `libselinux1` | SELinux runtime shared libraries |
| `libsemanage-common` | Common files for SELinux policy management libraries |
| `libsemanage2` | SELinux policy management library |
| `libsensors-config` | lm-sensors configuration files |
| `libsensors5` | library to read temperature/voltage/fan sensors |
| `libsepol2` | SELinux library for manipulating binary security policies |
| `libserd-0-0` | lightweight RDF syntax library |
| `libsframe1` | Library to handle the SFrame format (runtime library) |
| `libsharpyuv0` | Library for sharp RGB to YUV conversion |
| `libshine3` | Fixed-point MP3 encoding library - runtime files |
| `libslang2` | S-Lang programming library - runtime version |
| `libsm6` | X11 Session Management library |
| `libsmartcols1` | smart column output alignment library |
| `libsnappy1v5` | fast compression/decompression library |
| `libsndfile1` | Library for reading/writing audio files |
| `libsodium23` | Network communication, cryptography and signaturing library |
| `libsord-0-0` | library for storing RDF data in memory |
| `libsoxr0` | High quality 1D sample-rate conversion library |
| `libspectre1` | Library for rendering PostScript documents |
| `libspeex1` | Speex codec library (runtime library) |
| `libsphinxbase3t64` | Speech recognition tool - shared library |
| `libsqlite3-0` | SQLite 3 shared library |
| `libsratom-0-0` | library for serialising LV2 atoms to/from Turtle |
| `libsrt1.5-gnutls` | Secure Reliable Transport UDP streaming library (GnuTLS flavour) |
| `libssh-4` | tiny C SSH library (OpenSSL flavor) |
| `libssh2-1t64` | SSH2 client-side library |
| `libssl-dev` | Secure Sockets Layer toolkit - development files |
| `libssl3t64` | Secure Sockets Layer toolkit - shared libraries |
| `libstaroffice-0.0-0` | Import filter library to import all StarOffice documents |
| `libstartup-notification0` | library for program launch feedback (shared library) |
| `libstd-rust-1.85` | Rust standard libraries |
| `libstd-rust-dev` | Rust standard libraries - development files |
| `libstdc++6` | GNU Standard C++ Library v3 |
| `libsuitesparseconfig7` | configuration routines for all SuiteSparse modules |
| `libsvtav1enc2` | Scalable Video Technology for AV1 (libsvtav1enc shared library) |
| `libswresample5` | FFmpeg library for audio resampling, rematrixing etc. - runtime files |
| `libswscale8` | FFmpeg library for image scaling and various conversions - runtime files |
| `libsystemd0` | systemd utility library |
| `libtasn1-6` | Manage ASN.1 structures (runtime) |
| `libtcl8.6` | Tcl (the Tool Command Language) v8.6 - run-time library files |
| `libtext-charwidth-perl` | get display widths of characters on the terminal |
| `libtext-wrapi18n-perl` | internationalized substitute of Text::Wrap |
| `libthai-data` | Data files for Thai language support library |
| `libthai0` | Thai language support library |
| `libtheoradec1` | Theora Video Compression Codec (shared library - libtheoradec) |

<!-- page 20 -->

| `libtheoraenc1` | Theora Video Compression Codec (shared library - libtheoraenc) |
| `libthunarx-3-0` | extension library for thunar |
| `libtiff6` | Tag Image File Format (TIFF) library |
| `libtinfo6` | shared low-level terminfo library for terminal handling |
| `libtirpc-common` | transport-independent RPC library - common files |
| `libtirpc3t64` | transport-independent RPC library |
| `libtk8.6` | Tk toolkit for Tcl and X11 v8.6 - run-time files |
| `libtsan2` | ThreadSanitizer -- a Valgrind-based detector of data races (runtime) |
| `libtwolame0` | MPEG Audio Layer 2 encoding library |
| `libubsan1` | UBSan -- undefined behaviour sanitizer (runtime) |
| `libudev1` | libudev shared library |
| `libudfread0` | UDF reader library |
| `libunibreak6` | line breaking library for Unicode (shared library) |
| `libunistring5` | Unicode string library for C |
| `libuno-cppu3t64` | LibreOffice UNO runtime environment -- CPPU public library |
| `libuno-cppuhelpergcc3-3t64` | LibreOffice UNO runtime environment -- CPPU helper library |
| `libuno-purpenvhelpergcc3-3t64` | LibreOffice UNO runtime environment -- "purpose environment" helper |
| `libuno-sal3t64` | LibreOffice UNO runtime environment -- SAL public library |
| `libuno-salhelpergcc3-3t64` | LibreOffice UNO runtime environment -- SAL helpers for C++ library |
| `libunwind8` | library to determine the call-chain of a program - runtime |
| `libusb-1.0-0` | userspace USB programming library |
| `libutempter0` | privileged helper for utmp/wtmp updates (runtime) |
| `libuuid1` | Universally Unique ID library |
| `libuv1-dev` | asynchronous event notification library - development files |
| `libuv1t64` | asynchronous event notification library - runtime library |
| `libva-drm2` | Video Acceleration (VA) API for Linux -- DRM runtime |
| `libva-x11-2` | Video Acceleration (VA) API for Linux -- X11 runtime |
| `libva2` | Video Acceleration (VA) API for Linux -- runtime |
| `libvdpau1` | Video Decode and Presentation API for Unix (libraries) |
| `libvidstab1.1` | video stabilization library (shared library) |
| `libvisio-0.1-1` | library for parsing the visio file structure |
| `libvncclient1` | API to write one's own VNC server - client library |
| `libvncserver1` | API to write one's own VNC server |
| `libvorbis0a` | decoder library for Vorbis General Audio Compression Codec |
| `libvorbisenc2` | encoder library for Vorbis General Audio Compression Codec |
| `libvorbisfile3` | high-level API for Vorbis General Audio Compression Codec |
| `libvpl2` | Intel Video Processing Library -- shared library |
| `libvpx9` | VP8 and VP9 video codec (shared library) |
| `libvte-2.91-0` | Terminal emulator widget for GTK 3 - runtime files |
| `libvte-2.91-common` | Terminal emulator widget for GTK 3 - common files |
| `libvulkan1` | Vulkan loader library |
| `libwayland-client0` | wayland compositor infrastructure - client library |
| `libwayland-cursor0` | wayland compositor infrastructure - cursor library |
| `libwayland-egl1` | wayland compositor infrastructure - EGL library |
| `libwayland-server0` | wayland compositor infrastructure - server library |
| `libwebp7` | Lossy compression of digital photographic images (shared library) |

<!-- page 21 -->

| `libwebpdemux2` | Lossy compression of digital photographic images (libwebpdemux library) |
| `libwebpmux3` | Lossy compression of digital photographic images (libwebpmux library) |
| `libwnck-3-0` | Window Navigator Construction Kit - runtime files |
| `libwnck-3-common` | Window Navigator Construction Kit - common files |
| `libwpd-0.10-10` | Library for handling WordPerfect documents (shared library) |
| `libwpg-0.3-3` | WordPerfect graphics import/convert library (shared library) |
| `libwps-0.4-4` | Works text file format import filter library (shared library) |
| `libwrap0` | Wietse Venema's TCP wrappers library |
| `libx11-6` | X11 client-side library |
| `libx11-data` | X11 client-side library |
| `libx11-xcb1` | Xlib/XCB interface library |
| `libx264-164` | x264 video coding library |
| `libx265-215` | H.265/HEVC video stream encoder (shared library) |
| `libxau6` | X11 authorisation library |
| `libxaw7` | X11 Athena Widget library |
| `libxcb-composite0` | X C Binding, composite extension |
| `libxcb-damage0` | X C Binding, damage extension |
| `libxcb-dri3-0` | X C Binding, dri3 extension |
| `libxcb-glx0` | X C Binding, glx extension |
| `libxcb-image0` | utility libraries for X C Binding -- image |
| `libxcb-present0` | X C Binding, present extension |
| `libxcb-randr0` | X C Binding, randr extension |
| `libxcb-render-util0` | utility libraries for X C Binding -- render-util |
| `libxcb-render0` | X C Binding, render extension |
| `libxcb-shape0` | X C Binding, shape extension |
| `libxcb-shm0` | X C Binding, shm extension |
| `libxcb-sync1` | X C Binding, sync extension |
| `libxcb-util1` | utility libraries for X C Binding -- atom, aux and event |
| `libxcb-xfixes0` | X C Binding, xfixes extension |
| `libxcb1` | X C Binding |
| `libxcomposite1` | X11 Composite extension library |
| `libxcursor1` | X cursor management library |
| `libxdamage1` | X11 damaged region extension library |
| `libxdmcp6` | X11 Display Manager Control Protocol library |
| `libxdo3` | library for simulating (generating) X11 keyboard/mouse input events |
| `libxext6` | X11 miscellaneous extension library |
| `libxfce4ui-2-0` | widget library for Xfce - Gtk+3 variant |
| `libxfce4ui-common` | common files for libxfce4ui |
| `libxfce4util-common` | common files for libxfce4util |
| `libxfce4util7` | Utility functions library for Xfce4 |
| `libxfconf-0-3` | Client library for Xfce4 configure interface |
| `libxfixes3` | X11 miscellaneous 'fixes' extension library |
| `libxfont2` | X11 font rasterisation library |
| `libxft2` | FreeType-based font drawing library for X |
| `libxi6` | X11 Input extension library |
| `libxinerama1` | X11 Xinerama extension library |

<!-- page 22 -->

| `libxkbcommon0` | library interface to the XKB compiler - shared library |
| `libxkbfile1` | X11 keyboard file manipulation library |
| `libxml2` | GNOME XML library |
| `libxmlsec1t64` | XML security library |
| `libxmlsec1t64-nss` | Nss engine for the XML security library |
| `libxmu6` | X11 miscellaneous utility library |
| `libxmuu1` | X11 miscellaneous micro-utility library |
| `libxpm4` | X11 pixmap library |
| `libxpresent1` | X11 Present extension library |
| `libxrandr2` | X11 RandR extension library |
| `libxrender1` | X Rendering Extension client library |
| `libxres1` | X11 Resource extension library |
| `libxshmfence1` | X shared memory fences - shared library |
| `libxslt1.1` | XSLT 1.0 processing library - runtime library |
| `libxss1` | X11 Screen Saver extension library |
| `libxt6t64` | X11 toolkit intrinsics library |
| `libxtables12` | netfilter xtables library |
| `libxtst6` | X11 Testing -- Record extension library |
| `libxv1` | X11 Video extension library |
| `libxvidcore4` | Open source MPEG-4 video codec (library) |
| `libxxf86dga1` | X11 Direct Graphics Access extension library |
| `libxxf86vm1` | X11 XFree86 video mode extension library |
| `libxxhash0` | shared library for xxhash |
| `libyajl2` | Yet Another JSON Library |
| `libz3-4` | theorem prover from Microsoft Research - runtime libraries |
| `libzimg2` | scaling, colorspace, depth conversion library (shared library) |
| `libzix-0-0` | library of portability wrappers and data structures (shared library) |
| `libzmf-0.0-0` | Zoner Draw/Zebra file reading/converting library |
| `libzmq5` | lightweight messaging kernel (shared library) |
| `libzstd1` | fast lossless compression algorithm |
| `libzvbi-common` | Vertical Blanking Interval decoder (VBI) - common files |
| `libzvbi0t64` | Vertical Blanking Interval decoder (VBI) - runtime files |
| `libzxcvbn0` | password strength estimation library |
| `libzxing3` | C++ port of ZXing library (library files) |
| `linux-libc-dev` | Linux support headers for userspace development |
| `login` | system login tools |
| `login.defs` | system user management configuration |
| `mawk` | Pattern scanning and text processing language |
| `media-types` | List of standard media types and their usual file extension |
| `mesa-libgallium` | shared infrastructure for Mesa drivers |
| `mount` | tools for mounting and manipulating filesystems |
| `ncurses-base` | basic terminal type definitions |
| `ncurses-bin` | terminal-related programs and man pages |
| `net-tools` | NET-3 networking toolkit |
| `netbase` | Basic TCP/IP networking system |
| `node-abbrev` | Get unique abbreviations for a set of strings - Node.js module |

<!-- page 23 -->

| `node-acorn` | ECMAScript parser for Node.js |
| `node-agent-base` | Node.js wrapper around http.Agent class |
| `node-ajv` | another JSON Schema Validator |
| `node-ajv-keywords` | Custom JSON-Schema keywords for Ajv validator |
| `node-ampproject-remapping` | Nodejs module to remap sequential sourcemaps through transformations |
| `node-ansi-escapes` | ANSI escape codes for manipulating the terminal |
| `node-ansi-regex` | regular expression for matching ANSI escape codes |
| `node-ansi-styles` | ANSI escape codes for styling strings in the terminal with Node.js |
| `node-anymatch` | Matches strings against configurable strings |
| `node-aproba` | light-weight argument validator |
| `node-archy` | Pretty-print nested hierarchies module for Node.js |
| `node-are-we-there-yet` | Keep track of the overall completion of many disparate processes |
| `node-argparse` | CLI arguments parser for node.js |
| `node-arrify` | Convert a value to an array |
| `node-assert` | simple assertion library for javascript |
| `node-async` | functions and patterns for asynchronous code - Node.js |
| `node-async-each` | async parallel forEach / map function for JavaScript |
| `node-babel-helper-define-polyfill-provider` | node-babel helper for polyfills |
| `node-babel-plugin-add-module-exports` | Babel plugin for default module.exports like babel version 5 |
| `node-babel-plugin-lodash` | Modular Lodash builds without the hassle |
| `node-babel-plugin-polyfill-corejs2` | node-babel plugin to inject corejs2 polyfill |
| `node-babel-plugin-polyfill-corejs3` | node-babel plugin to inject corejs3 polyfill |
| `node-babel-plugin-polyfill-regenerator` | node-babel plugin to regenerate polyfills |
| `node-babel7` | Babel compiler for writing next generation JavaScript |
| `node-babel7-runtime` | Babel modular runtime helpers |
| `node-balanced-match` | Match balanced character pairs in Node.js |
| `node-base64-js` | Base64 encoding/decoding in pure JS |
| `node-binary-extensions` | List of binary file extensions |
| `node-brace-expansion` | Brace expansion as known from sh/bash for Node.js |
| `node-braces` | Fast, comprehensive, bash-like brace expansion implemented in JS |
| `node-browserslist` | Share browsers list between different front-end tools |
| `node-builtins` | lists nodejs builtin modules |
| `node-cacache` | fast, fault-tolerant, disk-based, data-agnostic, content-addressable cache |
| `node-camelcase` | Convert a string to camelCase |
| `node-caniuse-lite` | smaller version of caniuse-db, with only the essentials |
| `node-chalk` | Terminal string styling for Node.js |
| `node-chokidar` | wrapper around watch / watchFile / fsevents |
| `node-chownr` | like chown -R |
| `node-chrome-trace-event` | create a trace of your node app per Google's Trace Event format |
| `node-ci-info` | Get details about the current Continuous Integration environment |
| `node-cjs-module-lexer` | Fast lexer to extract named exports from CommonJS modules |
| `node-cli-table` | Pretty unicode tables for the CLI |
| `node-cliui` | easily create complex multi-column CLIs |
| `node-clone` | deep cloning of objects and arrays |
| `node-clone-deep` | Recursively (deep) clone JavaScript native types |
| `node-color-convert` | Plain color conversion functions |

<!-- page 24 -->

| `node-color-name` | list of color names and its values |
| `node-colors` | Get color and style in your node.js console |
| `node-columnify` | Render data in text columns with in-column text-wrap |
| `node-commander` | Complete solution for Node.js command-line interfaces |
| `node-commondir` | compute the closest common parent for file paths |
| `node-concat-stream` | writable stream that concatenates strings |
| `node-console-control-strings` | cross-platform tested terminal/console command strings |
| `node-convert-source-map` | Converts a source-map from/to between formats |
| `node-copy-concurrently` | Copy files, directories and symlinks concurrently |
| `node-core-js` | Modular standard library for JavaScript |
| `node-core-js-compat` | data about the necessity of core-js |
| `node-core-js-pure` | Modular standard library for JavaScript without global namespace pollution |
| `node-core-util-is` | util.is* functions introduced in Node v0.12 for older versions |
| `node-corepack` | Access npm, Yarn and pnpm without having to install them |
| `node-css-loader` | css loader module for webpack |
| `node-css-selector-tokenizer` | Parses and stringifies CSS selectors |
| `node-data-uri-to-buffer` | Node.js module that generate a Buffer instance from a Data URI string |
| `node-debbundle-es-to-primitive` | Pure javascript implementation of ToPrimitive algorithm |
| `node-debug` | small debugging utility for Node.js |
| `node-decamelize` | convert a camelized string into a lowercased one with a custom separator |
| `node-decompress-response` | Decompress a HTTP response if needed |
| `node-deep-equal` | node's assert.deepEqual algorithm |
| `node-deep-is` | node's assert.deepEqual algorithm except for NaN being equal to NaN |
| `node-defaults` | merge single level defaults over a config object |
| `node-define-properties` | Define multiple non-enumerable properties at once |
| `node-define-property` | Define property on an object |
| `node-defined` | return the first argument that is `!== undefined` |
| `node-del` | Delete files and folders |
| `node-delegates` | delegate methods and accessors to another property |
| `node-depd` | mark a function or property as deprecated - Node.js module |
| `node-diff` | javascript text differencing implementation |
| `node-doctrine` | JSDoc parser |
| `node-electron-to-chromium` | Provides a list of electron-to-chromium version mappings |
| `node-encoding` | Convert encodings, uses iconv by default and fallbacks to iconv-lite if needed |
| `node-enhanced-resolve` | Offers a async require.resolve function |
| `node-envinfo` | Generate reports of the common details used by Node.js packages |
| `node-err-code` | Create an error with a code |
| `node-errno` | libuv errno details exposed - Node.js module |
| `node-error-ex` | easy error subclassing and stack customization |
| `node-es-abstract` | ECMAScript spec abstract operations |
| `node-es-module-lexer` | Fast lexer to extract named exports from EcmaScript modules |
| `node-es6-error` | Easily-extendable error for use with ES6 classes |
| `node-escape-string-regexp` | Escape RegExp special characters in Node.js |
| `node-escodegen` | ECMAScript code generator |
| `node-eslint-scope` | ECMAScript scope analyzer for ESLint |
| `node-eslint-utils` | utilities for ESLint plugins |

<!-- page 25 -->

| `node-eslint-visitor-keys` | Constants and utilities about visitor keys to traverse AST |
| `node-espree` | Esprima-compatible JavaScript parser built on Acorn |
| `node-esprima` | ECMAScript parsing infrastructure for multipurpose analysis |
| `node-esquery` | query library for ECMAScript AST using CSS-like queries |
| `node-esrecurse` | ECMAScript AST recursive visitor |
| `node-estraverse` | ECMAScript JS AST traversal functions |
| `node-esutils` | utility box for ECMAScript language tools |
| `node-events` | Node.js events module to embed by web packers |
| `node-execa` | better `child_process` |
| `node-fancy-log` | Log things, prefixed with a timestamp |
| `node-fast-deep-equal` | Fast Deep Equal |
| `node-fast-levenshtein` | efficient implementation of Levenshtein algorithm |
| `node-fetch` | light-weight module that brings window.fetch to node.js |
| `node-file-entry-cache` | Node.js library implementing a simple cache for file metadata |
| `node-fill-range` | node module to fill in a range of numbers or letters |
| `node-find-cache-dir` | finds the common standard cache directory |
| `node-find-up` | Find a file by walking up parent directories |
| `node-flat-cache` | Node.js library implementing a simple persistent key/value storage |
| `node-flatted` | super light and fast circular JSON parser - Node library |
| `node-for-in` | iterate over object |
| `node-for-own` | Iterate over the own enumerable properties of an object |
| `node-foreground-child` | helper running a child process as a foreground process |
| `node-fs-readdir-recursive` | Recursively read a directory |
| `node-fs-write-stream-atomic` | Like fs.createWriteStream(...), but atomic |
| `node-fs.realpath` | Use node's fs.realpath |
| `node-function-bind` | Implementation of Function.prototype.bind |
| `node-functional-red-black-tree` | fully persistent balanced binary search tree - Node.js library |
| `node-gauge` | terminal based horizontal progress bar |
| `node-get-caller-file` | inspects the v8 stack trace |
| `node-get-stream` | Get a stream as a string, buffer, or array |
| `node-glob` | glob functionality for Node.js |
| `node-glob-parent` | Extract the non-magic parent path from a glob string |
| `node-globals` | Global identifiers from different JavaScript environments |
| `node-globby` | Extends glob with promise API |
| `node-got` | Simplified HTTP requests |
| `node-graceful-fs` | drop-in replacement improving the Node.js fs module |
| `node-gyp` | Native addon build tool for Node.js |
| `node-has-flag` | check if argv has a specific flag |
| `node-has-unicode` | Try to guess if your terminal supports unicode |
| `node-hosted-git-info` | Provides metadata from Github, Bitbucket and Gitlab |
| `node-http-proxy-agent` | HTTP(s) proxy http.Agent implementation for HTTP |
| `node-https-proxy-agent` | HTTP(s) proxy http.Agent implementation for HTTPS |
| `node-iconv-lite` | Pure JS character encoding conversion |
| `node-icss-utils` | ICSS utils for postcss ast |
| `node-ieee754` | Node.js module to read or write IEEE754 floating point numbers |
| `node-iferr` | Higher-order functions for easier error handling |

<!-- page 26 -->

| `node-ignore` | manager and filter for .gitignore rules - Node.js library |
| `node-imurmurhash` | incremental implementation of MurmurHash3 hashing algorithm |
| `node-indent-string` | Indent each line in a string |
| `node-inflight` | add callbacks to requests in flight to avoid async duplication |
| `node-inherits` | Node.js module that exposes inherits function |
| `node-ini` | ini format parser and serializer for Node.js |
| `node-interpret` | dictionary of file extensions and associated module loaders |
| `node-ip` | IP address utilities for node.js |
| `node-ip-regex` | Regular expression for matching IP addresses |
| `node-is-arrayish` | Determines if an object can be used as an array |
| `node-is-binary-path` | check if a filepath is a binary file |
| `node-is-buffer` | Determine if an object is a Buffer |
| `node-is-descriptor` | Returns true if value has characteristics of a valid JS descriptor |
| `node-is-extendable` | determine if a value can be extended |
| `node-is-extglob` | Node module to return true if a string is an extglob |
| `node-is-glob` | Node module to return true if a string is a glob or extglob |
| `node-is-number` | returns true if the value is a number |
| `node-is-path-cwd` | Check if a path is CWD |
| `node-is-path-inside` | Check if a path is inside another path |
| `node-is-plain-obj` | Check if a value is a plain object |
| `node-is-plain-object` | Returns true if object was created by `Object` constructor |
| `node-is-stream` | Check if something is a Node.js stream |
| `node-is-typedarray` | Nodejs library checking if object is TypedArray |
| `node-is-windows` | True if the platform is windows |
| `node-isarray` | JavaScript Array#isArray for older browsers |
| `node-isexe` | minimal module to check if a file is executable |
| `node-isobject` | Checks if the value is an object and not an array or null |
| `node-istanbul` | JavaScript code coverage tool |
| `node-jest-debbundle` | various ittle Node.js modules needed by jest |
| `node-jest-worker` | Nodejs module for executing heavy tasks under forked processes in parallel |
| `node-js-tokens` | Regex that tokenizes JavaScript |
| `node-js-yaml` | YAML 1.2 parser and serializer |
| `node-jsesc` | Escape JavaScript strings, with short output (Node.js module) |
| `node-json-buffer` | JSON functions that can convert buffers. |
| `node-json-parse-better-errors` | JSON.parse() with context information on error |
| `node-json-schema` | JSON Schema validation and specifications |
| `node-json-schema-traverse` | Json schema traversal package |
| `node-json-stable-stringify` | deterministic JSON.stringify() |
| `node-json5` | JSON for the ES5 era |
| `node-jsonify` | JSON without touching any globals |
| `node-jsonparse` | Pure javascript JSON streaming parser for node.js |
| `node-kind-of` | Get the native type of a value |
| `node-levn` | Light ECMAScript (JavaScript) Value Notation |
| `node-loader-runner` | Runs (webpack) loaders |
| `node-locate-path` | Get the first path that exists on disk of multiple paths |
| `node-lodash` | Lo-dash is a Node.js utility library |

<!-- page 27 -->

| `node-lodash-packages` | Lo-dash is a Node.js utility library (per method packages) |
| `node-lowercase-keys` | Lowercase the keys of an object |
| `node-lru-cache` | least-recently-used cache object for Node.js |
| `node-make-dir` | Make a directory and its parents if needed - Think mkdir -p |
| `node-memfs` | In-memory filesystem with Node's API |
| `node-memory-fs` | simple in-memory filesystem |
| `node-merge-stream` | Create a stream that emits events from multiple other streams |
| `node-micromatch` | Glob matching for javascript/node.js |
| `node-mime` | library for mime-type mapping for Node.js |
| `node-mime-types` | ultimate JavaScript content-type utility - Node.js module |
| `node-mimic-fn` | Make a function mimic another one |
| `node-mimic-response` | Mimic a Node.js HTTP response stream |
| `node-minimatch` | Convert glob expressions into RegExp objects for Node.js |
| `node-minimist` | Argument options parsing for Node.js |
| `node-minipass` | Minimal implementation of a PassThrough for Node.js |
| `node-mkdirp` | Recursively create directories - Node.js module |
| `node-move-concurrently` | Move files and directories concurrently |
| `node-ms` | milliseconds conversion utility - Node.js module |
| `node-mute-stream` | Pass-through stream that can be muted module for Node.js |
| `node-n3` | fast asynchronous streaming RDF for JavaScript - Node library |
| `node-negotiator` | HTTP content negotiator for Node.js |
| `node-neo-async` | faster replacement for Async |
| `node-nopt` | Command-line option parser for Node.js |
| `node-normalize-package-data` | Normalizes package metadata - Node.js module |
| `node-normalize-path` | Normalize file path slashes to be unix-like forward slashes |
| `node-npm-bundled` | Parses info on bundled dependencies |
| `node-npm-package-arg` | Parse the things that can be arguments to npm install |
| `node-npm-run-path` | Get your PATH prepended with locally installed binaries |
| `node-npmlog` | Logger with custom levels and colored output for Node.js |
| `node-object-assign` | ES2015 Object.assign() ponyfill |
| `node-object-inspect` | string representations of objects in node and the browser |
| `node-once` | Run a function only once with this module for Node.js |
| `node-optimist` | light-weight option parsing library for NodeJS |
| `node-optionator` | option parsing and help generation |
| `node-osenv` | Environment settings lookup module for Node.js |
| `node-p-cancelable` | Create a promise that can be canceled |
| `node-p-limit` | run multiple promise-returning & async functions |
| `node-p-locate` | async version of Array |
| `node-p-map` | Map over promises concurrently |
| `node-parse-json` | parse JSON with more helpful errors |
| `node-path-dirname` | Node.js library for function path.dirname ponyfill |
| `node-path-exists` | Check if a path exists |
| `node-path-is-absolute` | Node.js 0.12 path.isAbsolute() ponyfill |
| `node-path-is-inside` | Tests whether one path is inside another path |
| `node-path-type` | check if a path is a file, directory, or symlink |
| `node-picocolors` | library for terminal output formatting with colors (Node.js module) |

<!-- page 28 -->

| `node-pify` | promisify a callback-style function |
| `node-pkg-dir` | find the root directory of a npm package |
| `node-postcss` | Tool for transforming styles with JS plugins |
| `node-postcss-modules-extract-imports` | CSS Modules transform to extract local aliases for inline imports |
| `node-postcss-modules-values` | pass arbitrary values between your module files |
| `node-postcss-value-parser` | Transforms css values and at-rule params into the tree |
| `node-prelude-ls` | functionally oriented utility library for Livescript |
| `node-process-nextick-args` | process.nextTick but always with args |
| `node-progress` | Flexible ascii progress bar |
| `node-promise-inflight` | one promise for multiple requests in flight to avoid async duplication |
| `node-promise-retry` | Retries a function that returns a promise |
| `node-promzard` | Promzard provides a prompting json wizard |
| `node-prr` | Object.defineProperty() with common defaults - Node.js module |
| `node-punycode` | Nodejs robust Punycode converter fully RFC compliant |
| `node-quick-lru` | Simple "Least Recently Used" (LRU) cache |
| `node-randombytes` | random bytes from browserify stand alone |
| `node-read` | Read user input from stdin module for Node.js |
| `node-read-package-json` | Read package.json for npm module for Node.js |
| `node-read-pkg` | Read a package.json file |
| `node-readable-stream` | stream compatibility library for Node.js and browser |
| `node-readdirp` | Recursive version of Node.js's fs.readdir |
| `node-rechoir` | Node module to require any supported file as a node module |
| `node-regenerate` | Unicode-aware regular expression generator (Node.js module) |
| `node-regenerate-unicode-properties` | Unicode properties and values as Regenerate sets for Node.js |
| `node-regenerator-runtime` | Nodejs runtime for regenerator-compiled generator and async functions |
| `node-regenerator-transform` | Explode async and generator functions into a state machine |
| `node-regexpp` | regular expression parser for ECMAScript - Node.js library |
| `node-regexpu-core` | Core functionality for regexpu's functionality in Node.js |
| `node-regjsgen` | Regular expression from abstract syntax trees in Node.js |
| `node-regjsparser` | Parser for JavaScript's RegExp for Node.js |
| `node-repeat-string` | repeat the given string n times |
| `node-require-directory` | require all files in a directory |
| `node-resolve` | Synchronous/Asynchronous require.resolve() algorithm |
| `node-resolve-cwd` | Resolve the path of a module from current directory |
| `node-resolve-from` | Resolve the path of a module from a given path |
| `node-resumer` | through stream that starts paused and resumes on the next tick |
| `node-retry` | Retry strategies for failed operations module for Node.js |
| `node-rimraf` | Deep deletion (like rm -rf) module for Node.js |
| `node-run-queue` | promise based dynamic priority queue runner |
| `node-safe-buffer` | Safer Node.js Buffer API |
| `node-schema-utils` | Webpack Schema Validation Utilities |
| `node-semver` | Semantic Versioning for Node.js |
| `node-serialize-javascript` | serialize JavaScript to a superset of JSON |
| `node-set-blocking` | set blocking stdio and stderr |
| `node-set-immediate-shim` | Simple setImmediate shim |
| `node-shebang-command` | Get the command from a shebang |

<!-- page 29 -->

| `node-shebang-regex` | Regular expression for matching a shebang line |
| `node-signal-exit` | Fire an event no matter how a process exits |
| `node-slash` | Node.js library to convert Windows backslash paths to slash paths |
| `node-slice-ansi` | Slice a string with ANSI escape codes |
| `node-source-list-map` | Fast line to line SourceMap generator |
| `node-source-map` | Mozilla source map generator and consumer - Node.js module |
| `node-source-map-support` | Fixes stack traces for files with source maps |
| `node-spdx-correct` | correct invalid SPDX identifiers |
| `node-spdx-exceptions` | list of SPDX standard license exceptions |
| `node-spdx-expression-parse` | parse SPDX license expressions |
| `node-spdx-license-ids` | List of SPDX license identifiers |
| `node-sprintf-js` | Node.js Pure JavaScript sprintf implementation |
| `node-ssri` | Utility for parsing, serializing, generating and verifying  ssri metadata |
| `node-string-decoder` | string_decoder module from Node core for browsers |
| `node-string-width` | Get the visual width of a string |
| `node-strip-ansi` | Strip ANSI escape codes |
| `node-strip-bom` | Strip UTF-8 byte order mark (BOM) from a string |
| `node-strip-eof` | strip CR and LF characters from a string/buffer |
| `node-strip-json-comments` | Node.js module to strip comments from JSON |
| `node-supports-color` | Detect whether a terminal supports color in Node.js |
| `node-tapable` | just a little module for plugins |
| `node-tape` | tap-producing test harness for node and browsers |
| `node-tar` | read and write portable tar archives module for Node.js |
| `node-terser` | parser/mangler/compressor for ES6+ - Node.js library |
| `node-text-table` | borderless text tables with alignment |
| `node-through` | simplified stream construction |
| `node-time-stamp` | get a formatted timestamp |
| `node-to-fast-properties` | Force V8 to use fast properties for an object |
| `node-to-regex-range` | returns a regex-compatible range from two numbers, min and max |
| `node-tslib` | Implementation of tslib for javascript |
| `node-type-check` | Check the types of JavaScript values at runtime |
| `node-typedarray` | TypedArray polyfill for old browsers |
| `node-typedarray-to-buffer` | JavaScript utility converting TypedArray to buffer without copy |
| `node-undici` | Node.js HTTP/1.1 client |
| `node-unicode-canonical-property-names-ecmascript` | Unicode property names supported in ES RegExp in Node.js |
| `node-unicode-match-property-ecmascript` | Match a Unicode property to its canonical name for Node.js |
| `node-unicode-match-property-value-ecmascript` | Match a Unicode property value to its canonical version in Node.js |
| `node-unicode-property-aliases-ecmascript` | Unicode property aliases mapping for property names in Node.js |
| `node-unique-filename` | unique filename for use in temporary directories or caches |
| `node-uri-js` | URI/IRI parsing/validating/resolving library |
| `node-util` | NodeJS util module |
| `node-util-deprecate` | Node.js's `util.deprecate()` function with browser support |
| `node-uuid` | simple and fast RFC4122 UUID generation - Node.js module |
| `node-v8-compile-cache` | Leverage v8 compile cache to speedup loading of Node.js modules |
| `node-v8flags` | Get available V8 JavaScript engine flags |
| `node-validate-npm-package-license` | Tells if a string is a valid npm package license string |

<!-- page 30 -->

| `node-validate-npm-package-name` | Checks if a string is a valid npm package name |
| `node-watchpack` | Wrapper library for directory and file watching |
| `node-wcwidth.js` | wcwidth.js is a javascript porting of C's wcwidth() |
| `node-webassemblyjs` | Toolchain for WebAssembly |
| `node-webpack-sources` | Source code handling classes for webpack |
| `node-which` | Cross-platform 'which' module for Node.js |
| `node-wide-align` | Wide-character aware text alignment function |
| `node-wordwrap` | word wrapping library for NodeJS |
| `node-wrap-ansi` | Wordwrap a string with ANSI escape codes |
| `node-wrappy` | Callback wrapping utility |
| `node-write` | convenience wrapper for Node.js fs methods |
| `node-write-file-atomic` | Write files in an atomic fashion w/configurable ownership |
| `node-xtend` | Node.js library to easily extend an object |
| `node-y18n` | bare-bones internationalization library used by yargs |
| `node-yallist` | Double linked list implementation for Node.js |
| `node-yargs` | command line parser for nodejs |
| `node-yargs-parser` | mighty option parser used by yargs |
| `nodejs` | evented I/O for V8 javascript - runtime executable |
| `novnc` | HTML5 VNC client - daemon and programs |
| `npm` | package manager for Node.js |
| `ocl-icd-libopencl1` | Generic OpenCL ICD Loader |
| `openssl` | Secure Sockets Layer toolkit - cryptographic utility |
| `openssl-provider-legacy` | Secure Sockets Layer toolkit - cryptographic utility |
| `passwd` | change and administer password and group data |
| `patch` | Apply a diff file to an original |
| `perl` | Larry Wall's Practical Extraction and Report Language |
| `perl-base` | minimal Perl system |
| `perl-modules-5.40` | Core Perl modules |
| `picom` | lightweight compositor for X11 |
| `pinentry-curses` | curses-based PIN or pass-phrase entry dialog for GnuPG |
| `plank` | Elegant, simple, clean dock |
| `poppler-data` | encoding data for the poppler PDF rendering library |
| `poppler-utils` | PDF utilities (based on Poppler) |
| `procps` | /proc file system utilities |
| `psmisc` | utilities that use the proc file system |
| `python3` | interactive high-level object-oriented language (default python3 version) |
| `python3-bcrypt` | password hashing library for Python 3 |
| `python3-certifi` | root certificates for validating SSL certs and verifying TLS hosts (python3) |
| `python3-cffi-backend` | Foreign Function Interface for Python 3 calling C code - runtime |
| `python3-chardet` | Universal Character Encoding Detector (Python3) |
| `python3-charset-normalizer` | charset, encoding and language detection (Python 3) |
| `python3-cryptography` | Python library exposing cryptographic recipes and primitives |
| `python3-deprecated` | Python decorator for old classes, functions or methods |
| `python3-idna` | Python IDNA2008 (RFC 5891) handling (Python 3) |
| `python3-jwcrypto` | Python3 implementation of JOSE Web standards |
| `python3-minimal` | minimal subset of the Python language (default python3 version) |

<!-- page 31 -->

| `python3-numpy` | Python library for numerical computations (Python 3) |
| `python3-numpy-dev` | Python library for numerical computations (Python 3 headers) |
| `python3-packaging` | core utilities for python3 packages |
| `python3-pip` | Python package installer |
| `python3-pip-whl` | Python package installer (pip wheel) |
| `python3-redis` | Python bindings for Redis, a persistent key-value database |
| `python3-requests` | elegant and simple HTTP library for Python3, built for human beings |
| `python3-setuptools-whl` | Python Distutils Enhancements (wheel package) |
| `python3-typing-extensions` | Backported and Experimental Type Hints for Python |
| `python3-urllib3` | HTTP library with thread-safe connection pooling for Python3 |
| `python3-venv` | venv module for python3 (default python3 version) |
| `python3-websockify` | WebSockets support for any application/server - Python 3 |
| `python3-wheel` | built-package format for Python |
| `python3-wrapt` | decorators, wrappers and monkey patching. - Python 3.x |
| `python3.13` | Interactive high-level object-oriented language (version 3.13) |
| `python3.13-minimal` | Minimal subset of the Python language (version 3.13) |
| `python3.13-venv` | Interactive high-level object-oriented language (pyvenv binary, version 3.13) |
| `readline-common` | GNU readline and history libraries, common files |
| `ripgrep` | Recursively searches directories for a regex pattern |
| `rpcsvc-proto` | RPC protocol compiler and definitions |
| `rustc` | Rust systems programming language |
| `sed` | GNU stream editor for filtering/transforming text |
| `sensible-utils` | Utilities for sensible alternative selection |
| `shared-mime-info` | FreeDesktop.org shared MIME database and spec |
| `socat` | multipurpose relay for bidirectional data transfer |
| `sqv` | OpenPGP signature verification program from Sequoia |
| `sudo` | Provide limited super user privileges to specific users |
| `sysvinit-utils` | System-V-like utilities |
| `tar` | GNU version of the tar archiving utility |
| `tcl` | Tool Command Language (default version) - shell |
| `tcl8.6` | Tcl (the Tool Command Language) v8.6 - shell |
| `terser` | parser/mangler/compressor for ES6+ - CLI tool |
| `thunar` | File Manager for Xfce |
| `thunar-data` | Provides thunar documentation, icons and translations |
| `tk` | Toolkit for Tcl and X11 (default version) - windowing shell |
| `tk8.6` | Tk toolkit for Tcl and X11 v8.6 - windowing shell |
| `tmux` | terminal multiplexer |
| `tzdata` | time zone and daylight-saving time data |
| `ucf` | Update Configuration File(s): preserve user changes to config files |
| `uno-libs-private` | LibreOffice UNO runtime environment -- private libraries used by public ones |
| `unzip` | De-archiver for .zip files |
| `ure` | LibreOffice UNO runtime environment |
| `util-linux` | miscellaneous system utilities |
| `webpack` | Packs CommonJs/AMD modules for the browser |
| `websockify` | WebSockets support for any application/server |
| `wget` | retrieves files from the web |

<!-- page 32 -->

| `x11-common` | X Window System (X.Org) infrastructure |
| `x11-utils` | X11 utilities |
| `x11-xkb-utils` | X11 XKB utilities |
| `x11-xserver-utils` | X server utilities |
| `x11vnc` | VNC server to allow remote access to an existing X session |
| `xauth` | X authentication utility |
| `xdg-utils` | desktop integration utilities from freedesktop.org |
| `xdotool` | simulate (generate) X11 keyboard/mouse input events |
| `xfce4-terminal` | Xfce terminal emulator |
| `xfconf` | utilities for managing settings in Xfce |
| `xfonts-encodings` | Encodings for X.Org fonts |
| `xfonts-utils` | X Window System font utility programs |
| `xfwm4` | window manager of the Xfce project |
| `xkb-data` | X Keyboard Extension (XKB) configuration data |
| `xserver-common` | common files used by various X servers |
| `xvfb` | Virtual Framebuffer 'fake' X server |
| `zlib1g` | compression library - runtime |
