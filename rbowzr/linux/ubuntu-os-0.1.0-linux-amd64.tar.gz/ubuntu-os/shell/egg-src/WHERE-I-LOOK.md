# Where I look it up on this Linux machine

On this Linux machine I look in three places.

`/workspace` holds the egg, the Heart, and the Ubuntu prep.

`/home/box/agent-data` holds this chat's agent folder, skills, and settings.

`/opt/sand/sand-host` is the bundled host. I can read it, but it is not a source tree.

If the fact is not in one of those, it is not on this machine.
