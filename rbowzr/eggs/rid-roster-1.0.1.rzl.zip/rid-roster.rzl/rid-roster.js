// PUBLIC rid-roster 1.0.1 — ZERO seats. No ЯID of ours ships in any public download (Decider 2026-10-08 17:53/17:56 MT).
// One bot slot only: the install's own stock bot (the "local" row). Its ЯID is EMPTY here and is minted ON FIRST RUN by the
// GhostChain ЯID generator (~/ЯLAB/PROPOSALS/20261008-ghostchain-rid-generator/ · to define) — original, never one of ours.
// The Decider's own devices get the full verified roster on the private local update path, not from this file.
window.ROS_RID_LIST = {
 "schema": "rlab.ybowzr.rid-list.v1",
 "public": true,
 "scope": "public-egg",
 "rows": [],
 "groups": [],
 "slots": [
  {
   "slot": "self",
   "kind": "bot",
   "rid": null,
   "mint": "on-first-run",
   "generator": "ghostchain-rid-generator (to define)",
   "neverCollidesWith": "the Decider's private roster",
   "note": "empty until minted on this install"
  }
 ]
};
