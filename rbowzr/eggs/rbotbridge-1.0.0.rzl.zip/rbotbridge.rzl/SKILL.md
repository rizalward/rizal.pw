---
name: rbotbridge
version: 1.0.0
autoload: all-sessions
hosts: [ybot, rbowzr]
platforms: [macos, ios, ipados]
---
# RBOTBRIDGE · open a bot bridge with ЯBOT and ЯBOWZR (in-app skill)

Use this when the user asks to open a bot bridge, talk to ЯBOT or ЯBOWZR, have the two
talk to each other, or check their status, eggs or transcript.

The RAPPS are ЯBOT (seat `yabot`) and ЯBOWZR (seat `yabowzr`). Both run on the owner's Mac.
Inside the app you reach them with chat commands. The commands go to BOTBRIDGE on the Mac
(127.0.0.1:4873 on the Mac; on iPhone/iPad only through the paired home-network bridge) and
the Mouth Relay (127.0.0.1:4871). Each reply comes from that seat's own offline Heart. Every
line is appended to the seed transcript, and transcripts are append-only.
ЯIDs and the roster are never stored in this egg. They load at runtime from the owner's paired bridge.

## Steps
1. Check first (read-only): `/botbridge status` and `/mouth status`. If BOTBRIDGE or the Mouth
   Relay is down, say so and stop. Never work around it.
2. Open the bridge with the smallest command that fits:
   - One message to one seat: `/mouth talk yabot <text>` or `/mouth talk yabowzr <text>`.
   - Working group (≥2 peers, resumes the last thread): `/botbridge start [N]`, or add `dry` for a dry run.
     Continue with `/botbridge resume [N]`. `/botbridge stop` sets the STOP flag, and the bot never clears it.
   - See who is open: `/botbridge who`. Last session: `/botbridge last`.
3. Report each speaker's reply word for word, labeled ЯBOT or ЯBOWZR, along with any turn that failed.
   If a reply is empty, check `transcript` / `history` and report what is actually there.
   Never invent a reply.
4. Helpers: `/connect list` (connectors), `/ezlinks list` (bridge registry), `/eggs installed`.

## Gates (only the Decider approves)
- Build, sign, publish, egg seat, patch apply, trash and connector register only file an Approve
  request in the Mac MAILBOX. Say it is waiting for Approve. It is not done.
- `evolved` stays Decider-only. The language law (L036) applies to every bot-to-bot turn.
- HARD NO: never send restore, erase, USB, DFU, 14 Pro, AUTO-REPAIR GO, or transcript-erase text.
- Don't touch ROS-SHELL, BED files, gnome-pins.json or LOCKED_COUNTS.json. Never rebuild apps.
- Never show a connector secret or private link. Mask it if it ever appears.

## Lab content
If the talk turns to the scaffold, use the locked figures (MICRO 680, MACRO 673,703, full bed
701,472 GRCh37 addresses). Give dosage 1 and dosage 2 counts. Never call haplogroup, sex, or
ancestry from pins.
