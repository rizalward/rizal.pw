"use strict";
/* ЯBOT bots-panel 1.1.9 · CHATS shim — lets ЯBOWZR's chatlist.js (verbatim from ЯBOWZR 1.2.8) run inside ЯBOT's bots panel.
   ЯBOT's scout-app.js has no BOTBRIDGE route helpers, so these are copied verbatim from ЯBOWZR 1.2.8 scout-app.js and only
   defined when missing. Mac: loopback 127.0.0.1:4873 (no token). iPhone/iPad: the pair card (bbPair) saves a LAN route + token on
   this device only (localStorage "rlab.botbridge.route"); the token is never shown again. No roster data is bundled: rows come at
   runtime from BOTBRIDGE GET /v1/klassroom/rid-list (the real ЯKLASSROOM roster + group rooms). HARD NO erase/USB/14 Pro. */
window.ROS_MOUTH_ID = window.ROS_MOUTH_ID || "yabot";
/* ── verbatim from ЯBOWZR 1.2.8 scout-app.js lines 419–435 ── */
function seatMouthId() { return window.ROS_MOUTH_ID || (/RBOWSER-web\.bundle/.test(String(location.pathname)) ? "yabot" : "yabowzr"); }
function bbIsIOS() { const n = navigator; return /iPhone|iPad|iPod/.test(n.userAgent) || (/Macintosh/.test(n.userAgent) && n.maxTouchPoints > 1); }
function botbridgeRoute() {
  let saved = {}; try { saved = JSON.parse(localStorage.getItem("rlab.botbridge.route") || "{}"); } catch (e) { saved = {}; }
  return { url: window.ROS_BOTBRIDGE_URL || saved.url || "http://127.0.0.1:4873", token: window.ROS_BOTBRIDGE_TOKEN || saved.token || "" };
}
function bbHeaders(route, json) { const h = {}; if (json) h["content-type"] = "application/json"; if (route.token) h.authorization = "Bearer " + route.token; return h; }
function bbPair(req) {
  try {
    if (req.clear) { localStorage.removeItem("rlab.botbridge.route"); return "BOTBRIDGE pairing cleared on this device."; }
    const lan = /^http:\/\/((10|127)\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|[A-Za-z0-9-]+\.local):\d{2,5}$/;
    if (!lan.test(req.url || "")) return "Pair refused: LAN only, e.g. /botbridge pair http://<your-mac>.local:4873 <token>";
    if (!/^[A-Za-z0-9_-]{24,128}$/.test(req.token || "")) return "Pair refused: that token does not look right.";
    localStorage.setItem("rlab.botbridge.route", JSON.stringify({ url: req.url, token: req.token }));
    return `BOTBRIDGE paired · ${req.url} · token saved on this device only.`;
  } catch (e) { return "Pair failed: storage unavailable."; }
}
