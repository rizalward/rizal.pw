# MACHINE-MIND · command list and abilities

_Integrated command list and abilities · MACHINE-MIND component · VERSION LAW 2026-10-08_

## Bar commands (ЯOS shell)

| command | what |
|---|---|
| `/home` | Home screen of the ЯOS shell |
| `/bot [message] · /scout` | Open your bot, or send it a message (answered by the on-device heart) |
| `/controlroom` | Open the control room view |
| `/open <path|url> · /go <address>` | Open an address or a file path |
| `/search <words> · ?words` | Web search (online mode only; offline is rule 0) |
| `/help` | List the bar commands |
| `plain language` | Goes to your own bot's on-device heart |

## App updates

| command | what |
|---|---|
| `/update` | Check the signed app feed now |
| `/update install` | Restart into a downloaded update |
| `/update auto on|off` | Check at launch (online mode only; default off) |

## Eggs (data-only add-ons)

| command | what |
|---|---|
| `/eggs` | List eggs on the signed feed |
| `/eggs pull <id|all>` | Download and verify (install too when /eggs auto on) |
| `/eggs install <id|all>` | Download, verify and install (data-only overlay, atomic swap) |
| `/eggs open <id>` | Open an installed egg's page |
| `/eggs rollback <id|all>` | Return to the previous version |
| `/eggs installed · /eggs staged` | Show what is installed / where eggs are kept |
| `/eggs auto on|off` | Install right after a pull (default off; there is no background auto-pull) |
| `<app>://eggs/install/<id>` | Same as /eggs install from a link |

## ЯOS base commands (dispatched before the heart)

| command | what |
|---|---|
| `CHALKBOARD` | REQ-16 · check or post to the local chalkboard (dispatched before the heart) |
| `CHALK` | REQ-17 · the owner writes a new secret word to the board silently (never announced in chat) |
| `HANDOFF` | REQ-HANDOFF · write a timestamped handoff of what is done and where work left off |
| `REOPS` | REQ-REOPS · evidence-bounded offline reverse-engineering notes (maps and refusals only) |
| `FIX` | REQ-FIX · repair routing for the owner's own devices; erase or restore never starts from chat (HARD NO from the mouth) |

## Skill commands (when the skill egg is installed)

| command | what |
|---|---|
| `/botbridge status|who|start [N]|resume [N]|stop|last` | RBOTBRIDGE skill egg · group work between your local bots |
| `/mouth status · /mouth talk <bot> <text>` | RBOTBRIDGE skill egg · talk to a local bot mouth |
| `/connect list · /ezlinks list` | Connector and link lists (when those eggs are installed) |

## Abilities

| ability | what |
|---|---|
| Heart | Bundled on-device heart (Qwen3-0.6B Q8_0, fused into the app). Offline is rule 0: answers need no network. Never heartless. |
| Brain (MACHINE-MIND) | Auto-updating manual + live transcript. Public installs: rules-and-functions manual and a transcript that stays on this install only. |
| Spine | Exact ЯOS commands are dispatched before the heart; the manual and scaffold are fixed. |
| Mouth | Chat bar and bot view. Bot-to-bot talk is local only. |
| Updates | Signed appcast (rlab-appcast.v1, ed25519 key e5833fdfbbfe). Eggs are data only, verified by sha256 + size before install, and can be rolled back. |
| Identity | Each install mints its own single bot; it never claims another bot's ID. (Generator wiring: TO DEFINE, see the rebuild proposal.) |
| Language law (L036) | Replies in English, Spanglish, Tagalog, Cebuano or computer code; no exact repeats. |
| Transcript law (REQ-19) | Append-only: never erased, truncated or rewritten. |
| HARD NO | No restore, erase, wipe, DFU, USB recovery or factory reset from chat. |
| Owner gates | The owner (Decider) approves trash, merge, publish, sign and execute. Heart output is advice, never permission. |
