# HOST-ADAPTER · API a future app or shell must expose to load ЯSEED

ЯSEED 0.1.0 runs inside any host that speaks this small contract. ЯBOT (`ybot`) and ЯBOWZR (`rbowzr`) already do via `/eggs open yaseed` (WKWebView). New apps (ROS-SHELL-KIT / rlab-new templates) inherit the same surface.

## Injection
Before loading the egg page scripts, set:

```js
globalThis.YASEED_HOST = {
  hostId: 'ybot' | 'rbowzr' | 'ros-shell' | '<your-app>',
  platform: 'ios' | 'ipados' | 'macos' | 'node' | ...,
  // sha256 of the .rzl.zip the updater already verified (optional; enrollment parent prefers it)
  releaseSha256: '<hex from appcast>',
  // optional install ЯID; never required
  getYaId: async () => null | '<yaid>',
  // optional paired-bridge handle for opportunistic sync (never required; never blocking)
  bridge: null | { sendBundle: async (json) => {}, onBundle: (cb) => {} },
  // optional storage override; default is IndexedDB `yaseed-0.1`
  storage: null
};
```

## Required behaviour
1. Serve the egg's `index.html` (or call `new YaSeedCore.YaSeed({ host }).boot()` yourself).
2. Stay offline-capable: the host must not require network for ЯSEED to grow/train/code/evolve/sign/chain.
3. Never block UI or boot on a peer device being online.
4. If a bridge exists, treat it as opportunistic only: pull `YASEED.core.queueOutbound()` when convenient; push received bundles into `YASEED.core.importBundle(bundle)`.
5. Optional native bar hook: `await window.YASEED.command('/yaseed status')`.

## Forbidden
- Injecting a release/private key into the egg.
- Asking the device key to sign app updates or appcast entries (the egg refuses).
- Auto-pulling peers at boot.

## Minimal new-app template
```js
globalThis.YASEED_HOST = { hostId: 'my-app', platform: 'ios', getYaId: async () => null };
// load yaseed-core.js + yaseed-panel.js (or boot headlessly)
const eng = new YaSeedCore.YaSeed({ host: YASEED_HOST });
await eng.boot();           // mints device key + enrollment on first run
await eng.command('/yaseed grow');
```
