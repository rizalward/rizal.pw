# MODEL-PLUGIN · register a new architecture under ЯSEED

The founding model (`founding-ternary-loop`) ships in the egg. Later architectures register as **signed modules** under the same Ghost Chain + device-delegate rules.

## Shape
```js
const plugin = {
  id: 'my-arch',            // lowercase / hyphen
  version: '0.1.0',
  description: '…',
  // optional source (sandboxed JS, same rules as /yaseed modify)
  source: `
    exports.create = function (api) { return { forward() { return 0; } }; };
    exports.selftest = function (api) { return api.assert(!!exports.create, 'create'); };
  `,
  create(eng) { /* return a model handle */ },
  selftest(api) { return api.assert(true, 'ok'); }
};
await eng.registerPlugin(plugin);
```

## Rules
- Device-signed under scope `yaseed.model-plugin`.
- Sandbox: no network, no host APIs, no release-key access.
- Loaded only after `selftest` passes; failures are chained as `plugin.reject` and not loaded.
- May read egg storage only through the engine API the host already gave ЯSEED.
- Anything that leaves the sandbox still needs Rizal's Approve.
- Works fully offline on one device; peer sync of plugin descriptors is opportunistic via chain bundles.

## Founding model
`founding-ternary-loop` @ 0.1.0 — ternary sparse blocks + byte-level looped MLP. Commands: `/yaseed grow|train|expert|evolve|code|build|create|modify`.
