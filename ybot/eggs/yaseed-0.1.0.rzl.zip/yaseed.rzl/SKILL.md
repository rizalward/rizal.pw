---
name: yaseed
version: 0.1.0
autoload: all-sessions
hosts: [rbowzr, ybot]
platforms: [macos, ios, ipados]
---
# ЯSEED 0.1.0 · on-device seed core (ЯENJIN 0.1 · L048)

ЯSEED grows its own small model on this device from a seed. It loads no borrowed weights
and makes no network calls. Open it with `/eggs open yaseed`, then type `/yaseed …` in its panel
or tap a button.

## Commands
| Command | What it does |
|---|---|
| `/yaseed grow` | Plant this install's seed and grow 4 ternary {-1,0,+1} sparse blocks with the generator MLP. Each block is hashed and chained with the seed as parent. |
| `/yaseed train [sec]` | Train the tiny byte-level looped model on the built-in ЯLAB lesson lines in short bursts so the UI stays responsive (default 60 s). Reports the loss before and after. |
| `/yaseed expert` | Add an expert: a new codebook row plus a block grown from it, chained as a delta. Its gate starts at 0, and training learns it. |
| `/yaseed evolve [tries]` | Mutate, run a mini-eval, and keep the change only if the loss improves. Losers are recorded and never loaded. |
| `/yaseed rollback [seq\|prev]` | Restore an earlier chained snapshot, checked against its chained state hash. The chain itself only grows. |
| `/yaseed status` · `/yaseed chain verify` · `/yaseed chain tail [n]` | Status, a full chain check, and the latest records. |

## Function 0 · Ghost Chain
Every action is an append-only record: `prev_hash → entry_hash` (SHA-256 over canonical JSON).
Each record is signed with this install's own non-extractable ECDSA P-256 key, held in WebCrypto
and stored in IndexedDB. That is the device attestation key, not the release key. If the chain
fails verification at boot, ЯSEED refuses to act and allows only status and chain verify.

## Rules
- Offline is rule 0. There is no fetch, XHR or WebSocket, and the panel CSP sets `connect-src 'none'`.
- Act then speak: quote the real loss and entry counts that the panel prints.
- HARD NO: USB, restore, erase, DFU and 14 Pro requests are refused and recorded as a refusal.
- Version stays 0.1 (ЯENJIN). Seat, sign and publish wait for the Decider's Approve.
