# FORMAT-RID · Package ЯID (rid.v1) · function 0 tagging

**Status:** ЯENJIN / RBL 0.1 · 2026-10-10 MT  
**Scope:** every *data package* on the Ghost Chain (prompt, reply, action, model, egg, seed, block, …).  
**Not this format:** seat/entity IDs (`ЯID-0002-PQ2Q`) and stock LOCAL IDs (`LOCAL-XXXX-XXXX`) — those stay as they are.

## Form
```
Я-<CLASS>-<BODY10>-<CK2>
```
Example: `Я-SEED-A1B2C3D4E5-K7`

| Part | Meaning |
|------|---------|
| `Я-` | Literal prefix (package namespace; seats use `ЯID-`) |
| `CLASS` | One of: DATA PROMPT REPLY ACTION MODEL EGG SEED BLOCK EXPERT KEY DEVICE EVENT |
| `BODY10` | Crockford Base32 (no I,L,O,U), 10 chars = first 56 bits of SHA-256 |
| `CK2` | 2 Crockford chars — checksum over `CLASS\|BODY` |

## Material (deterministic)
```
sha256( payload_hash + "|" + parent + "|" + device + "|" + seq + "|" + CLASS )
```
- `payload_hash` — hex SHA-256 of the payload (no `sha256:` prefix in the material string)
- `parent` — parent package id or entry hash, or empty
- `device` — device fingerprint / key_fp / host id
- `seq` — integer Ghost Chain sequence that will carry this record (or the aliased seq on backfill)
- Same inputs ⇒ same ЯID in Python (`rzl_rid.py`) and JS (`yaseed` rid module). Cross-test: `testdata/rid-vectors.json`.

## Bootloader rule (RBL function 0)
1. No package passes the gate without an ЯID.
2. The ЯID is stored on the chain record body as `rid`.
3. Internal `package_id` (`rzl:pkg:…`) remains for lineage; `rid` is the human/index tag.
4. Index: `state/rid-index.sqlite` (rebuildable). Commands: `rzl rid …`, `rzl index …`, `rzl monitor`.
5. Backfill never rewrites history — it appends `rid.alias` records pointing at old entries.

## Checksum
Catches typos: changing any BODY/CLASS char fails `rzl rid verify`.
