/* ЯSEED 0.1.0 · panel: boots the on-device core and wires the /yaseed command line + buttons. No network. */
(function () {
  'use strict';
  var out = document.getElementById('out'), inp = document.getElementById('cmd'), st = document.getElementById('st');
  var core = new window.YaSeedCore.YaSeed({});
  function say(t) { out.textContent += t + '\n\n'; out.scrollTop = out.scrollHeight; }
  function lock(on) { Array.prototype.forEach.call(document.querySelectorAll('button,input'), function (b) { if (b.dataset.cmd !== '/yaseed stop') b.disabled = on; }); }
  async function run(text) {
    if (!text) return; say('> ' + text); lock(true);
    try {
      var r = await core.command(text, function (p) { st.textContent = 'training · ' + p.steps + ' steps · batch loss ' + p.batch_loss.toFixed(3) + ' · ' + p.elapsed.toFixed(1) + 's'; });
      say(r);
    } catch (e) { say('ЯSEED: ' + (e && e.message || e)); }
    lock(false); refresh();
  }
  async function refresh() { try { var s = await core.status(); st.textContent = (s.chain_ok ? 'chain OK' : 'CHAIN BROKEN') + ' · ' + s.chain_entries + ' entries · key ' + s.key_fp + (s.loss != null ? ' · loss ' + s.loss + ' · experts ' + s.experts : ' · not grown') + ' · ' + s.storage + ' · offline'; } catch (e) { st.textContent = String(e); } }
  document.querySelectorAll('button[data-cmd]').forEach(function (b) { b.addEventListener('click', function () { if (b.dataset.cmd === '/yaseed stop') { core.stopFlag = true; return; } run(b.dataset.cmd); }); });
  document.getElementById('f').addEventListener('submit', function (ev) { ev.preventDefault(); var t = inp.value.trim(); inp.value = '/yaseed '; run(t); });
  window.YASEED = { command: function (t) { return core.command(t); }, core: core, version: window.YaSeedCore.VERSION };
  core.boot().then(function (b) {
    say(b.ok ? 'ЯSEED ' + window.YaSeedCore.VERSION + ' booted · Ghost Chain verified (' + b.verify.entries + ' entries)' + (b.grown ? ' · model resumed' : ' · tap Grow to start') : 'Ghost Chain BROKEN: ' + b.verify.problems.join('; ') + '\nЯSEED refuses to act (status / chain verify only).');
    refresh();
  }).catch(function (e) { say('boot failed: ' + (e && e.message || e)); });
})();
