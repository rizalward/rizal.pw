// PUBLIC STUB — no ЯID roster, replies or avatars are bundled in ANY build (public or the Decider's phone).
// The list fills at runtime: this phone's roster store (verified + confirmed .rbotpack transfer) or the paired BOTBRIDGE feed.
window.ROS_RID_LIST = { schema: "rlab.ybowzr.rid-list.v1", public: true, rows: [], groups: [] };
