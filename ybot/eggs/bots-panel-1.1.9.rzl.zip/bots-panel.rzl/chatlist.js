"use strict";
// ЯBOWZR landing list 1.0.0 (Decider 2026-10-07 19:21 t221u + 19:23 t222u) — Grok Bot style chat list in front of the bot view.
// Row = avatar (+status dot where known) · bold NAME · full ЯID chip · time of latest reply · one-line summary · blue unread dot.
// Rows: every ЯID bot from the bridge-classroom roster (window.ROS_RID_LIST, bundled snapshot from ~/ЯLAB/TOOLS/rid-roster-snapshot.py),
// this device's own local bot(s), and real group threads from the record. Sorted by latest reply, newest first.
// Tap a row → that bot's / group's MAIN CONVERSATION page (thread + composer). The profile opens from the chat header (name/avatar).
// Never invents a reply ("No replies yet · <state>"). Live refresh: botbridge GET /v1/session/last on the paired route
// (token only from this device's own pairing storage — never bundled, never shown); offline → the snapshot stays, nothing breaks.
// 1.1.0 (t223u/t224u): NOTHING personal is bundled in public builds (rid-roster.js is an empty stub). Rows come at runtime from
//   (1) this phone's roster store (seated only by a verified, Decider-confirmed .rbotpack transfer · rosBotPack) and
//   (2) the paired BOTBRIDGE (GET /v1/klassroom/rid-list) — otherwise "Pair to see your classroom".
// ЯID Botbridge utility: ⚡ in the chat header (and /rid <ЯID> join|ping|open|open-klassroom|transfer-in|transfer-out in the composer,
//   yabowzr://botbridge?rid=…&action=…, the "Botbridge by ЯID" Shortcut). handoff/recall/stealth/wake stay locked.
(function chatList() {
  const BUNDLED = (window.ROS_RID_LIST && typeof window.ROS_RID_LIST === "object") ? window.ROS_RID_LIST : { rows: [], groups: [] };
  let SNAP = { rows: (BUNDLED.rows || []).slice(), groups: (BUNDLED.groups || []).slice(), generatedAt: BUNDLED.generatedAt };
  let rosterFrom = (BUNDLED.rows || []).length ? "bundled snapshot" : "";
  const nativeBP = (cmd, extra) => {
    const h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.rosBotPack;
    if (!h) return Promise.resolve({ ok: false, error: "no native host (browser preview)" });
    return h.postMessage(Object.assign({ cmd }, extra || {})).catch((e) => ({ ok: false, error: String(e) }));
  };
  const $ = (s, r = document) => r.querySelector(s);
  const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

  function fmtTime(at, long) {
    if (!at) return "";
    const d = new Date(at); if (isNaN(d)) return "";
    const now = new Date();
    const t = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    if (long) return d.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + t;
    if (d.toDateString() === now.toDateString()) return t;
    const y = new Date(now); y.setDate(now.getDate() - 1);
    if (d.toDateString() === y.toDateString()) return "Yesterday";
    return d.toLocaleDateString([], { month: "short", day: "numeric" });
  }
  window.ROS_FMT_TIME = fmtTime;

  const STATE_DOT = { callable: "on", "this-device": "on", "receiver-only": "idle", "rebuild-later": "later" };
  let byId = {};
  function reindex() { byId = {}; for (const r of SNAP.rows || []) byId[r.id] = r; }
  reindex();
  const idOf = (rid) => String(rid || "").replace(/^ЯID-/, "");
  // ── OWNER · Chief main control room (t231u) ── top-left avatar. Saved on THIS device (native owner/profile.json + avatar.png).
  // Linked ЯID = the owner the paired BOTBRIDGE names (rid-list "owner"); fresh public installs edit their own stock owner ("Chief").
  // Nothing about the Decider ships in the app: name/photo come from this device's saved profile or the paired roster at runtime.
  const OWNER_STOCK = { name: "Chief", title: "Main control room", description: "This device's owner · tap the top-left picture to change photo, name and description." };
  const PROF = (typeof PROFILES !== "undefined" && PROFILES) ? PROFILES : {};
  let ownerP = PROF.owner && typeof PROF.owner === "object" ? Object.assign({}, PROF.owner) : null;   // saved owner profile (null = never edited)
  let ownerRid = ownerP && /^ЯID-\d{4}-[0-9A-Z]{4}$/.test(ownerP.rid || "") ? ownerP.rid : null;
  function ownerRow() { return ownerRid ? byId[idOf(ownerRid)] || null : null; }
  function ownerEntry() {
    const r = ownerRow(), P = ownerP || {};
    const e = { key: "owner", seq: "owner", kind: "owner", rid: ownerRid, color: (r && r.color) || "#e85d2a",
      name: P.name || (r && r.name) || OWNER_STOCK.name,
      title: P.title != null ? P.title : ((r && r.title) || OWNER_STOCK.title),
      blurb: P.description || (r && (r.description || r.title)) || OWNER_STOCK.description,
      tile: P.avatar || (r && (r.avatarSrc || r.avatarData || (r.avatar ? "./" + r.avatar : null))) || null };
    e.glyph = [...e.name][0] || "C"; e.call = e.name;
    return e;
  }
  function applyOwner() {   // saved owner profile wins on this device: the owner's row, its chat header, group stacks and the bots rail
    if (!ownerP || !ownerRid) return;
    const r = byId[idOf(ownerRid)];
    if (r) { r.name = ownerP.name || r.name; if (ownerP.title != null) r.title = ownerP.title; if (ownerP.description) r.description = ownerP.description;
             if (ownerP.avatar) { r.avatarSrc = ownerP.avatar; r.avatarData = ownerP.avatar; } }
    for (const e of (typeof CLASSROOM_ROSTER !== "undefined" ? CLASSROOM_ROSTER : [])) {
      if (e.rid !== ownerRid) continue;
      e.name = ownerP.name || e.name; e.call = e.name; if (ownerP.title != null) e.title = ownerP.title; if (ownerP.description) e.blurb = ownerP.description; if (ownerP.avatar) e.tile = ownerP.avatar;
    }
  }
  // merge a roster source (store bots / bridge feed rows) — by ЯID, never duplicated; newer replies win
  function mergeRows(rows, groups, from) {
    for (const r0 of rows || []) {
      if (!r0 || !r0.rid || r0.state === "retired") continue;   // retired ЯIDs stay merged (no IDs in the app)
      const id = r0.id || idOf(r0.rid);
      const cur = byId[id];
      const r = Object.assign({}, cur || {}, r0, { id, kind: "bot" });
      if (cur && cur.last && (!r0.last || Date.parse(cur.last.at || 0) > Date.parse(r0.last.at || 0))) { r.last = cur.last; r.history = cur.history; }
      if (r0.avatarData) r.avatarSrc = r0.avatarData; else if (cur && cur.avatarSrc) r.avatarSrc = cur.avatarSrc;
      if (cur) Object.assign(cur, r); else SNAP.rows.push(r);
    }
    for (const g of groups || []) {
      const i = SNAP.groups.findIndex((x) => x.id === g.id);
      if (i < 0) SNAP.groups.push(Object.assign({}, g));
      else if (!SNAP.groups[i].last || (g.last && Date.parse(g.last.at || 0) >= Date.parse(SNAP.groups[i].last.at || 0))) SNAP.groups[i] = Object.assign({}, g);
    }
    reindex(); if (from) rosterFrom = from;
    applyOwner();
  }
  async function loadStore() {
    const st = await nativeBP("store");
    if (!st || !st.ok) return st;
    const rec = st.record || {};
    const recRows = {}; for (const r of rec.rows || []) recRows[r.rid] = r;
    const rows = (st.bots || []).map((b) => Object.assign({}, recRows[b.rid] || {}, { rid: b.rid, name: b.name, rosterName: b.rosterName, title: b.title, role: b.role,
      state: b.state, mouth: b.mouth, glyph: b.glyph, color: b.color, avatarData: b.avatarData, dossier: b.dossier, seat: b.seat, seatedOnPhone: true }));
    if (rows.length) { mergeRows(rows, rec.groups || [], "this phone's roster (transferred)"); if (rec.generatedAt) SNAP.generatedAt = rec.generatedAt; }
    storeInfo = st;
    return st;
  }
  let storeInfo = null, feedState = "";

  // this device's own bots (stock ЯBOT with its LOCAL ID + user-made bots) — last reply from the on-device transcript (REQ-19 file)
  function localRows() {
    const out = [];
    const lastBot = [...(typeof persistedTranscript !== "undefined" ? persistedTranscript : []),
                     ...(typeof pastSessions !== "undefined" ? pastSessions.flat() : []), ...(typeof transcript !== "undefined" ? transcript : [])]
      .filter((l) => l && l.role === "bot" && typeof l.text === "string" && !/^History restored ·|^── session /.test(l.text)).pop();
    for (const e of (typeof CLASSROOM_ROSTER !== "undefined" ? CLASSROOM_ROSTER : [])) {
      if (!(e.key === "stock-bot" || /^bot-/.test(e.key))) continue;
      const lastAt = lastBot && lastBot.at && !isNaN(Date.parse(lastBot.at)) ? lastBot.at : null;   // REQ-19 line ts (displayTurns "at")
      out.push({ kind: "local", id: "local:" + e.key, entry: e, name: e.name, rid: e.rid || (typeof localId === "function" && localId(e.key)) || "LOCAL ID", title: e.title || "This phone",
                 state: "this-device", avatarSrc: e.tile || avatarDataUri(e),
                 last: e.key === "stock-bot" && lastBot ? { at: lastAt, text: lastBot.text, source: "this phone · transcript (REQ-19)", from: e.name } : null });
    }
    return out;
  }

  function avatarFor(row) {
    if (row.avatarSrc) return row.avatarSrc;
    if (row.avatarData) return row.avatarData;
    if (row.avatar) return "./" + row.avatar;
    return avatarDataUri({ color: row.color || "#444", glyph: row.glyph || [...(row.name || "?")][0] });
  }
  function allRows() {
    const rows = [...localRows(), ...(SNAP.rows || []).map((r) => ({ ...r })), ...(SNAP.groups || []).map((g) => ({ ...g }))];
    const t = (r) => (r.last && r.last.at) ? Date.parse(r.last.at) : (r.last ? 0 : -1);   // untimed record lines after timed ones; no reply last
    return rows.sort((a, b) => t(b) - t(a));
  }

  // unread = latest reply newer than the last time this row was seen on this device (first run: everything counts as seen)
  const SEEN_KEY = "rlab.ridlist.seen.v1";
  let seen = {}; try { seen = JSON.parse(localStorage.getItem(SEEN_KEY) || "null") || null; } catch (e) { seen = null; }
  const firstRun = !seen; if (!seen) seen = {};
  function markSeen(row) { if (row.last && row.last.at) { seen[row.id] = row.last.at; try { localStorage.setItem(SEEN_KEY, JSON.stringify(seen)); } catch (e) {} } }
  function unread(row) { return !!(row.last && row.last.at && seen[row.id] && Date.parse(row.last.at) > Date.parse(seen[row.id])); }

  // ── DOM ──
  const list = mk("section"); list.id = "chatlist"; list.setAttribute("aria-label", "Chats");
  const top = mk("div", "cl-top");
  const me = mk("img", "cl-me"); me.alt = "Chief · main control room profile"; me.setAttribute("role", "button"); me.tabIndex = 0;
  me.setAttribute("aria-label", "Edit Chief main control room profile");
  const search = mk("input", "cl-search"); search.type = "search"; search.placeholder = "Search name · ЯID · reply"; search.hidden = true;
  const sBtn = mk("button", "cl-round", "⌕"); sBtn.type = "button"; sBtn.setAttribute("aria-label", "Search");
  const add = mk("button", "cl-round", "+"); add.type = "button"; add.setAttribute("aria-label", "New bot");
  const sp = mk("div", "cl-spacer");
  top.append(me, sp, search, sBtn, add);
  const ul = mk("div", "cl-rows"); ul.setAttribute("role", "list");
  const foot = mk("div", "cl-foot");
  list.append(top, ul, foot);
  document.body.prepend(list);

  const head = mk("div"); head.id = "thread-head";
  const back = mk("button", "th-back", "‹"); back.type = "button"; back.setAttribute("aria-label", "Back to chats");
  const who = mk("button", "th-who"); who.type = "button"; who.setAttribute("aria-label", "Open profile");
  const whoAv = mk("span", "th-av"); const whoTx = mk("span", "th-tx"); const whoName = mk("span", "th-name"); const whoRid = mk("span", "th-rid");
  whoTx.append(whoName, whoRid); who.append(whoAv, whoTx); head.append(back, who);
  const main = $("main"); main.prepend(head);
  const info = mk("section"); info.id = "thread-info"; info.hidden = true; document.body.append(info);

  let liveNote = "";
  function render() {
    const q = search.value.trim().toLowerCase();
    const oe = ownerEntry();
    me.src = oe.tile || avatarDataUri(oe);
    window.ROS_HEART_FROM = `${oe.name}${oe.rid ? " " + oe.rid : ""} (this device's owner)`;   // the heart's identity line names the sender
    ul.replaceChildren();
    const rows = allRows();
    if (firstRun) { for (const r of rows) markSeen(r); }
    for (const row of rows) {
      const hay = [row.name, row.rid, row.title, row.last && row.last.text].join(" ").toLowerCase();
      if (q && !hay.includes(q)) continue;
      const li = mk("button", "cl-row" + (row.kind === "group" ? " group" : "")); li.type = "button"; li.setAttribute("role", "listitem");
      li.setAttribute("aria-label", `${row.name}${row.rid ? " " + row.rid : ""}`);
      const av = mk("span", "cl-av");
      if (row.kind === "group") {
        const ms = (row.members || []).slice(0, 3).map((id) => byId[id]).filter(Boolean);
        av.classList.add("stack");
        ms.forEach((m, i) => { const im = mk("img", "st st" + i); im.src = avatarFor(m); im.alt = ""; av.append(im); });
      } else {
        const im = mk("img"); im.src = avatarFor(row); im.alt = ""; av.append(im);
        const dot = STATE_DOT[row.state]; if (dot) av.append(mk("span", "cl-dot " + dot));
      }
      const body = mk("span", "cl-body");
      const l1 = mk("span", "cl-l1");
      const nm = mk("span", "cl-name", row.name);
      l1.append(nm);
      if (row.kind !== "group") l1.append(mk("span", "cl-chip", row.rid || "no ЯID"));
      else l1.append(mk("span", "cl-chip grp", `${(row.members || []).length} bots`));
      const tm = mk("span", "cl-time" + (unread(row) ? " new" : ""), fmtTime(row.last && row.last.at));
      l1.append(tm);
      const l2 = mk("span", "cl-l2");
      const sum = mk("span", "cl-sum");
      if (row.last) sum.textContent = (row.kind === "group" && row.last.from ? row.last.from + ": " : "") + row.last.text;
      else { sum.textContent = `No replies yet · ${row.state || "unknown"}`; sum.classList.add("none"); }
      l2.append(sum);
      if (unread(row)) l2.append(mk("span", "cl-unread"));
      body.append(l1, l2);
      li.append(av, body);
      if (row.kind !== "local") {
        const nub = mk("span", "cl-nub", "⚡"); nub.setAttribute("role", "button"); nub.setAttribute("aria-label", `Botbridge · ${row.name}`);
        nub.addEventListener("click", (ev) => { ev.stopPropagation(); openThread(row); openSheet(); });
        l1.append(nub);
      }
      li.addEventListener("click", () => openThread(row));
      ul.append(li);
    }
    if (!(SNAP.rows || []).length) {
      const card = mk("div", "cl-pair");
      card.append(mk("div", "cl-pair-t", "Pair to see your classroom"),
        mk("div", "cl-pair-s", feedState === "refused" ? "BOTBRIDGE refused this phone — pair again." : "Your Klassroom roster and latest replies load from your own BOTBRIDGE after pairing, or from a ЯID transfer (.rbotpack). Nothing personal ships inside the app."),
        mk("code", "cl-pair-c", "/botbridge pair http://<your-mac>.local:4873 <token>"));
      ul.append(card);
    }
    foot.textContent = `${rows.length} chats · ${rosterFrom ? "roster: " + rosterFrom : "no roster yet"}${SNAP.generatedAt ? " · record " + fmtTime(SNAP.generatedAt, true) : ""}${liveNote ? " · " + liveNote : ""}${ownerNote ? " · " + ownerNote : ""}`;
  }

  function entryFor(row) {
    if (row.kind === "local") return row.entry;
    const key = row.kind === "group" ? row.id : "rid-" + row.id.toLowerCase();
    let e = CLASSROOM_ROSTER.find((x) => x.key === key);
    if (!e) {
      e = norm({ key, seq: key, name: row.name, call: row.name, rid: row.kind === "group" ? null : row.rid, kind: row.kind === "group" ? "group" : (row.role || "rbot"),
                 title: row.kind === "group" ? `${(row.members || []).length} bots` : row.title, color: row.color, glyph: row.glyph,
                 tile: row.kind === "group" ? null : (row.avatar ? "./" + row.avatar : null),
                 blurb: row.kind === "group" ? (row.note || "") : `${row.rosterName || row.name} · ${row.role || ""} · state ${row.state || "?"}${row.mouth ? " · mouth " + row.mouth : ""}` });
      if (typeof PROFILES !== "undefined" && PROFILES[key]) applyProfile(e, PROFILES[key]);
      CLASSROOM_ROSTER.push(e);
    }
    return e;
  }

  let current = null;
  function openThread(row) {
    current = row; markSeen(row);
    const e = entryFor(row);
    const local = row.kind === "local";
    selectProfile(e, { announce: true, card: false, greet: local });       // REQ-19: switching archives the visible session, never erases
    if (!local) {
      for (const h of row.history || []) transcript.push({ role: "peer", from: h.from, at: h.at, text: h.text, source: h.source });
      if (!(row.history || []).length) transcript.push({ role: "note", text: `No replies yet · ${row.state || "unknown"}. This bot has no reply in the classroom/bridge record.` });
      const mouthHint = row.mouth ? ` Live: /connect ${row.mouth} <message> through BOTBRIDGE.` : "";
      transcript.push({ role: "note", text: (row.kind === "group" ? `Group record · ${row.note || ""}.` : `Record · latest ${Math.min((row.history || []).length, 12)} line(s) from the classroom/bridge record.`) +
        ` Messages you type here go to the local ЯBOWZR shell (offline).${mouthHint}` });
      draw();
    }
    whoName.textContent = row.name;
    whoRid.textContent = row.kind === "group" ? (row.members || []).map((id) => (byId[id] || {}).name || id).join(", ") : (row.rid || "");
    whoAv.replaceChildren();
    if (row.kind === "group") { (row.members || []).slice(0, 3).map((id) => byId[id]).filter(Boolean).forEach((m, i) => { const im = mk("img", "st st" + i); im.src = avatarFor(m); whoAv.append(im); }); whoAv.classList.add("stack"); }
    else { const im = mk("img"); im.src = avatarFor(row); whoAv.append(im); whoAv.classList.remove("stack"); }
    document.body.classList.add("thread"); document.body.classList.remove("listing");
    info.hidden = true;
    const msg = $("#message"); if (msg) msg.placeholder = `Message ${row.name}`;
    const lg = $("#log"); if (lg) requestAnimationFrame(() => { lg.scrollTop = lg.scrollHeight; });   // chat opens at the latest reply
  }
  function showList() {
    document.body.classList.remove("thread"); document.body.classList.add("listing"); info.hidden = true;
    if (current) markSeen(current);
    render();
  }
  function showInfo() {
    if (!current) return;
    info.replaceChildren();
    const close = mk("button", "ti-close", "Done"); close.type = "button"; close.addEventListener("click", () => { info.hidden = true; });
    info.append(close);
    if (current.kind === "group") {
      info.append(mk("div", "ti-title", current.name), mk("div", "ti-note", current.note || ""));
      for (const id of current.members || []) {
        const m = byId[id]; if (!m) continue;
        const b = mk("button", "ti-member"); b.type = "button";
        const im = mk("img"); im.src = avatarFor(m); b.append(im, mk("span", "ti-mn", m.name), mk("span", "ti-mr", m.rid));
        b.addEventListener("click", () => openThread(m)); info.append(b);
      }
    } else {
      info.append(profileCard(entryFor(current)));
      if (current.last) info.append(mk("div", "ti-note", `Latest reply · ${fmtTime(current.last.at, true) || "this phone"} · ${current.last.source}`));
      else info.append(mk("div", "ti-note", `No replies yet · ${current.state || "unknown"}`));
    }
    info.hidden = false;
  }
  back.addEventListener("click", showList);
  who.addEventListener("click", showInfo);
  sBtn.addEventListener("click", () => { search.hidden = !search.hidden; if (!search.hidden) search.focus(); else { search.value = ""; render(); } });
  search.addEventListener("input", render);
  add.addEventListener("click", () => { if (typeof newBot === "function") newBot(); });
  document.addEventListener("click", (ev) => { if (ev.target && ev.target.classList && ev.target.classList.contains("pe-save")) setTimeout(() => { if (!document.body.classList.contains("thread")) render(); }, 400); }, true);

  // live refresh (botbridge working group) — read-only GET, 3 s budget, silent when offline
  async function feed() {
    try {
      if (typeof botbridgeRoute !== "function") return;
      const route = botbridgeRoute();
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 6000);
      const r = await fetch(route.url + "/v1/klassroom/rid-list", { headers: bbHeaders(route), signal: ctl.signal }); clearTimeout(t);
      if (r.status === 401 || r.status === 403) { feedState = "refused"; return; }
      if (!r.ok) { feedState = "bridge " + r.status; return; }
      const j = await r.json();
      if (j && j.rows) {
        if (j.owner && /^ЯID-\d{4}-[0-9A-Z]{4}$/.test(j.owner) && j.owner !== ownerRid) { ownerRid = j.owner; linkOwner(); }
        mergeRows(j.rows, j.groups, "BOTBRIDGE (paired)"); SNAP.generatedAt = j.generatedAt; feedState = "ok";
      }
    } catch (e) { feedState = "offline"; }
  }
  async function live() {
    try {
      if (typeof botbridgeRoute !== "function") return;
      await feed();
      const route = botbridgeRoute();
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 3000);
      const r = await fetch(route.url + "/v1/session/last", { headers: bbHeaders(route), signal: ctl.signal }); clearTimeout(t);
      if (!r.ok) { liveNote = `bridge ${r.status}`; render(); return; }
      const j = await r.json();
      const M = {}; for (const r of SNAP.rows || []) if (r.mouth) M[r.mouth] = r.id;   // mouth → row from the runtime roster (no IDs in the app)
      const g = (SNAP.groups || []).find((x) => x.id === "grp-botbridge");
      let n = 0;
      for (const turn of (j.turns || [])) {
        if (turn.type !== "turn" || !turn.reply || !turn.ts) continue;
        const at = new Date(String(turn.ts).replace(/([+-]\d{2})(\d{2})$/, "$1:$2")).toISOString();
        const rec = { at, text: String(turn.reply).replace(/\s+/g, " ").slice(0, 600), source: "live · botbridge /v1/session/last", from: (byId[M[turn.mouthId]] || {}).name || turn.mouthId };
        const row = byId[M[turn.mouthId]];
        if (row && (!row.last || Date.parse(at) > Date.parse(row.last.at || 0))) { row.last = rec; (row.history = row.history || []).push(rec); n++; }
        if (g && (!g.last || Date.parse(at) > Date.parse(g.last.at || 0))) { g.last = rec; (g.history = g.history || []).push(rec); n++; }
      }
      liveNote = `live bridge ${new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}${n ? ` · ${n} newer` : ""}`;
      if (!document.body.classList.contains("thread")) render();
    } catch (e) { /* offline: snapshot stays */ }
  }

  // ── owner editor (t231u) ──
  function nativeProfile(msg) {
    const h = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.rosProfile;
    if (!h) return Promise.resolve({ ok: false, error: "no native host" });
    return h.postMessage(msg).catch((e) => ({ ok: false, error: String(e) }));
  }
  function linkOwner() {   // a saved owner profile remembers the ЯID the paired bridge named (no photo re-sent; native keeps avatar.png)
    if (!ownerP || ownerP.rid === ownerRid) return;
    ownerP.rid = ownerRid;
    nativeProfile({ cmd: "save", key: "owner", profile: { name: ownerP.name, title: ownerP.title || "", description: ownerP.description || "", linkRid: ownerRid }, avatar: null });
  }
  let ownerNote = "";
  async function syncOwner(profile, avatar) {   // paired only: POST /v1/rid/profile → bridge backs up, then updates the owner's roster entry
    if (!ownerRid) return "saved on this device · not linked to a ЯID (pair BOTBRIDGE to sync)";
    let route; try { route = botbridgeRoute(); } catch (e) { return "saved on this device · BOTBRIDGE not paired"; }
    if (!route || !route.token) return "saved on this device · BOTBRIDGE not paired";
    try {
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
      const r = await fetch(route.url + "/v1/rid/profile", { method: "POST", headers: bbHeaders(route, true), signal: ctl.signal,
        body: JSON.stringify({ rid: ownerRid, name: profile.name, title: profile.title || "", description: profile.description || "", avatarData: avatar || null }) });
      clearTimeout(t);
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.ok) return `synced to ${ownerRid} on BOTBRIDGE (backup ${j.backup || "made"})`;
      return `saved on this device · bridge refused sync (${j.error || r.status})`;
    } catch (e) { return "saved on this device · BOTBRIDGE unreachable (sync later by saving again)"; }
  }
  function openOwner() {
    if (typeof openProfileEditor !== "function") return;
    const e = ownerEntry();
    openProfileEditor(e, { owner: true, onSaved: async (profile, avatar) => {
      ownerP = Object.assign({}, ownerP || {}, { name: profile.name, title: profile.title, description: profile.description, rid: ownerRid || (ownerP && ownerP.rid) || null });
      if (avatar) ownerP.avatar = avatar;
      if (typeof PROFILES !== "undefined" && PROFILES) PROFILES.owner = Object.assign({}, ownerP);
      applyOwner();
      if (current && ownerRid && current.id === idOf(ownerRid)) openThread(byId[current.id] || current);   // refresh the open chat header
      ownerNote = "Chief profile saved"; render();
      ownerNote = await syncOwner(profile, avatar); render();
      if (ownerRid && /^synced/.test(ownerNote)) setTimeout(() => { live(); }, 1500);
    } });
  }
  me.addEventListener("click", openOwner);
  me.addEventListener("keydown", (ev) => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); openOwner(); } });
  window.ROS_EDIT_OWNER = openOwner;

  // ── ЯID Botbridge utility ───────────────────────────────────────────────────────────────────────────────
  const ALLOWED = ["join", "ping", "open", "open-klassroom", "transfer-in", "transfer-out"];
  const LOCKED = ["handoff", "recall", "stealth", "wake"];
  function say(text, cls) { transcript.push({ role: "note", text }); if (document.body.classList.contains("thread")) draw(); }
  function sayPeer(from, text, source) { transcript.push({ role: "peer", from, at: new Date().toISOString(), text, source }); if (document.body.classList.contains("thread")) draw(); }
  // retired ЯIDs resolve to the bot they were merged into (from the runtime roster's left_out / mergedInto — no IDs in the app)
  function resolveRid(rid) {
    rid = String(rid || "");
    const lo = SNAP.left_out || {};
    for (const k of Object.keys(lo)) { const m = String(lo[k]).match(/merged into (?:ЯID-)?([0-9]{4}-[0-9A-Z]{4})/); if (m && rid.replace(/^ЯID-/, "") === k.replace(/^ЯID-/, "")) return "ЯID-" + m[1]; }
    return rid;
  }
  function klassroomRow() {
    return SNAP.groups.find((g) => g.id === "grp-chalkboard") || SNAP.groups.find((g) => /klassroom|classroom|chalkboard/i.test(g.name || "")) ||
      { kind: "group", id: "klassroom", name: "Klassroom", members: [], note: "pair BOTBRIDGE (or transfer the roster) to load the classroom record" };
  }
  function rowFor(rid) {
    if (!rid) return null;
    if (rid === "klassroom") return klassroomRow();
    rid = resolveRid(rid);
    if (/^grp-/.test(rid)) return SNAP.groups.find((g) => g.id === rid) || null;
    return byId[idOf(rid)] || null;
  }
  async function bridgeAct(rid, action, via) {
    action = String(action || "open").toLowerCase(); via = via || "app";
    if (rid && rid !== "ALL" && rid !== "klassroom" && !/^grp-/.test(rid)) { const to = resolveRid(rid); if (to !== rid) { say(`${rid} is retired · read-only alias of ${to}.`); rid = to; } }
    if (rid === "klassroom") rid = klassroomRow().id;
    if (LOCKED.includes(action)) { say(`${action} is LOCKED until the Decider approves it. Only join · ping · open · transfer (with your confirm) work by ЯID.`); return { ok: false, locked: true }; }
    if (!ALLOWED.includes(action)) { say(`Refused: ${action} is not a Botbridge action (join · ping · open · open-klassroom · transfer-in · transfer-out).`); return { ok: false }; }
    const row = rowFor(rid);
    if (action === "transfer-in") return transferIn(rid || "ALL", via);
    if (action === "transfer-out") return transferOut(rid || "ALL", via);
    const route = typeof botbridgeRoute === "function" ? botbridgeRoute() : { url: "http://127.0.0.1:4873", token: "" };
    try {
      const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), action === "ping" ? 200000 : 8000);
      const r = await fetch(route.url + "/v1/rid", { method: "POST", headers: bbHeaders(route, true), signal: ctl.signal,
        body: JSON.stringify({ rid, action, via, device: (window.ROS_INSTALL && window.ROS_INSTALL.rid) || "" }) });
      clearTimeout(t);
      if (r.status === 401 || r.status === 403) { say(`BOTBRIDGE refused this phone (${r.status}) — pair first: /botbridge pair http://<your-mac>.local:4873 <token>. ${rid || ""} state here: ${(row && row.state) || "unknown"}.`); return { ok: false, status: r.status }; }
      const j = await r.json();
      if (action === "ping" && j.ok && j.reply) sayPeer(j.name || rid, j.reply, `live · BOTBRIDGE /v1/rid ping (${via})`);
      else say(`⚡ ${action} · ${j.text || JSON.stringify(j).slice(0, 300)}`);
      if (action === "open-klassroom" && j.ok && (j.groups || []).length) { const g = SNAP.groups.find((x) => x.id === "grp-chalkboard") || SNAP.groups.find((x) => j.groups.includes(x.id)); if (g && via === "url") openThread(g); }
      return j;
    } catch (e) {
      say(`⚡ ${action} · BOTBRIDGE unreachable from this phone (offline or not paired) · ${rid || "?"} state: ${(row && row.state) || "unknown"} · nothing was sent.`);
      return { ok: false, offline: true };
    }
  }
  async function transferIn(rid, via, file) {
    let payload = null;
    if (file) payload = { file };
    else {
      const route = botbridgeRoute();
      try {
        const r = await fetch(route.url + "/v1/rbotpack?rid=" + encodeURIComponent(rid) + "&target=" + encodeURIComponent("ЯBOWZR phone"), { headers: bbHeaders(route) });
        if (r.status === 401 || r.status === 403) { say("Transfer-in needs a paired BOTBRIDGE (or open a .rbotpack from Files)."); return { ok: false }; }
        const j = await r.json(); if (!j.ok) { say(`Transfer-in: Mac could not build the pack (${j.error || "?"}).`); return j; }
        payload = { pack: j.pack };
      } catch (e) { say("Transfer-in: BOTBRIDGE unreachable · open a .rbotpack from Files instead · nothing changed."); return { ok: false, offline: true }; }
    }
    say(`Transfer-in ${rid} · verifying signature + sha256 · your confirm is required…`);
    const res = await nativeBP("import", payload);
    if (res.ok) {
      const x = res.result || {};
      say(`Transfer-in ✓ signer ${res.signer} · content ${String(res.contentSha256 || "").slice(0, 12)} · seated ${x.seated.length} · no-op ${x.noop.length} · replaced ${x.replaced.length} (backed up ${x.backups.length}) · refused ${Object.keys(x.refused || {}).length}`);
      await loadStore(); render();
    } else say(`Transfer-in ✗ ${res.rejected || res.why || res.error || "refused"}`);
    return res;
  }
  async function transferOut(rid, via) {
    const res = await nativeBP("export", { rid, target: "neo-mac", share: via !== "bridge-only" });
    if (!res.ok) { say(`Transfer-out ✗ ${res.why || res.error || "refused"}`); return res; }
    say(`Transfer-out ✓ ${res.file} · ${res.bytes} bytes · sha ${String(res.sha256).slice(0, 12)} · content ${String(res.contentSha256).slice(0, 12)} · signer ${res.signer}`);
    try {
      const route = botbridgeRoute();
      const r = await fetch(route.url + "/v1/rbotpack", { method: "POST", headers: bbHeaders(route, true), body: JSON.stringify({ pack: res.pack }) });
      const j = await r.json(); say(`Mac: ${j.text || (j.ok ? "verified" : "rejected")}`);
    } catch (e) { say("Mac not reachable · the pack stays in Documents/ЯLAB/OUTBOX (share sheet / Files)."); }
    return res;
  }
  window.ROS_BRIDGE = bridgeAct;
  // header ⚡ sheet
  const bolt = mk("button", "th-bolt", "⚡"); bolt.type = "button"; bolt.setAttribute("aria-label", "Botbridge · Klassroom"); head.append(bolt);
  const sheet = mk("div"); sheet.id = "bridge-sheet"; sheet.hidden = true; document.body.append(sheet);
  function openSheet() {
    if (!current) return;
    sheet.replaceChildren();
    const rid = current.kind === "group" ? current.id : current.rid;
    sheet.append(mk("div", "bs-title", `Botbridge · ${current.name}`), mk("div", "bs-sub", `${rid || "local"} · ${current.state || (current.kind === "group" ? "group" : "")}`));
    const acts = current.kind === "group" ? [["join", "Join room"], ["open-klassroom", "Open Klassroom"]]
      : current.kind === "local" ? [["transfer-out", "Transfer roster out (ALL)"]]
      : [["join", "Activate · join"], ["ping", "Ping"], ["open-klassroom", "Open Klassroom"], ["transfer-in", "Transfer in from Mac"], ["transfer-out", "Transfer out to Mac"]];
    for (const [a, label] of acts) {
      const b = mk("button", "bs-act", label); b.type = "button";
      b.addEventListener("click", () => { sheet.hidden = true; bridgeAct(current.kind === "local" ? "ALL" : rid, a, "app"); });
      sheet.append(b);
    }
    if (current.kind !== "local") {
      const link = current.kind === "group" ? (current.id === "grp-chalkboard" || current.id === "klassroom" ? "yabowzr://klassroom" : `yabowzr://botbridge?rid=${current.id}&action=open`) : `yabowzr://botbridge?rid=${rid}&action=ping`;
      for (const [mins, label] of [[15, "Alarm · check in 15 min"], [60, "Alarm · check in 1 hour"]]) {
        const b = mk("button", "bs-act", label); b.type = "button";
        b.addEventListener("click", async () => { sheet.hidden = true; const r = await nativeBP("alarm", { rid, name: current.name, minutes: mins, action: current.kind === "group" ? "open" : "ping" });
          say(r.ok ? `⏰ Alarm set · ${current.name} · ${mins} min · local notification only` : `⏰ Alarm not set · ${r.error || "?"}`); });
        sheet.append(b);
      }
      const cl = mk("button", "bs-act", "Copy link · " + link); cl.type = "button";
      cl.addEventListener("click", async () => { sheet.hidden = true; const r = await nativeBP("copy", { text: link });
        if (!r.ok) { try { await navigator.clipboard.writeText(link); } catch (e) {} } say(`🔗 Copied ${link}`); });
      sheet.append(cl);
    }
    sheet.append(mk("div", "bs-lock", "handoff · recall · stealth · wake — locked until the Decider approves"));
    const c = mk("button", "bs-cancel", "Cancel"); c.type = "button"; c.addEventListener("click", () => { sheet.hidden = true; }); sheet.append(c);
    sheet.hidden = false;
  }
  bolt.addEventListener("click", openSheet);
  // composer: /rid <ЯID|ALL|grp-…> <action>
  document.addEventListener("submit", (ev) => {
    const m = $("#message"); const v = m && m.value.trim();
    const mm = v && v.match(/^\/rid\s+(\S+)\s+([a-z-]+)\s*$/i);
    if (!mm) return;
    ev.preventDefault(); ev.stopImmediatePropagation(); m.value = "";
    const rid = /^grp-/i.test(mm[1]) ? mm[1].toLowerCase() : mm[1].toUpperCase().replace(/^RID-/, "ЯID-");
    transcript.push({ role: "note", text: `/rid ${rid} ${mm[2].toLowerCase()}` }); draw();
    bridgeAct(rid, mm[2], "app");
  }, true);
  // pairing survives relaunch: the page store is non-persistent, so the route also lives in the device Keychain
  if (typeof bbPair === "function") {
    const orig = bbPair;
    bbPair = function (req) { const out = orig(req); if (/^BOTBRIDGE paired/.test(out)) nativeBP("pairSave", { url: req.url, token: req.token }); if (/cleared/.test(out)) nativeBP("pairSave", { clear: true }); return out; };
  }
  async function restorePair() {
    try { if (localStorage.getItem("rlab.botbridge.route")) return; } catch (e) { return; }
    const p = await nativeBP("pairGet");
    if (p && p.ok && p.url && p.token) { try { localStorage.setItem("rlab.botbridge.route", JSON.stringify({ url: p.url, token: p.token })); } catch (e) {} }
  }

  render();
  if (window.ROS_HAD_PENDING) { const lr = localRows()[0]; if (lr) { current = lr; document.body.classList.add("thread"); whoName.textContent = lr.name; whoRid.textContent = lr.rid; const im = mk("img"); im.src = avatarFor(lr); whoAv.replaceChildren(im); } }
  else document.body.classList.add("listing");
  (async () => {
    await loadStore(); await restorePair(); render();
    await live();
    if (!document.body.classList.contains("thread")) render();
    const A = window.ROS_BRIDGE_ACTION;                         // URL scheme / Shortcut
    if (A && typeof A === "object") {
      window.ROS_BRIDGE_ACTION = null;
      if (A.action === "edit-owner") { showList(); openOwner(); return; }   // yabowzr://owner (t231u)
      let row = rowFor(A.rid);
      if (!row && A.rid && !/^grp-/.test(A.rid) && A.rid !== "ALL") row = { kind: "bot", id: idOf(A.rid), rid: A.rid, name: A.rid, state: "not on this phone's roster" };
      if (row) openThread(row);
      else if (A.rid === "ALL" || !A.rid) { const st = (typeof CLASSROOM_ROSTER !== "undefined") && localRows()[0]; if (st) openThread(st); }
      if (A.action === "locked") say(`${A.asked} is LOCKED until the Decider approves it (from the URL scheme). Nothing was done.`);
      else if (A.action === "refused") say(`Refused from the URL scheme: "${A.asked}" is not a Botbridge action.`);
      else if (A.badRid) say(`Refused from the URL scheme: "${A.badRid}" is not an ЯID.`);
      else if (A.action === "transfer-in") transferIn(A.rid || "ALL", "url", A.file);
      else if (A.rid === "klassroom" && A.ask) {                  // yabowzr://klassroom?ask=… → one message to this phone's heart in the classroom
        transcript.push({ role: "note", text: `yabowzr://klassroom · asking this phone's heart: "${A.ask}"` }); draw();
        const prevFrom = window.ROS_HEART_FROM; window.ROS_HEART_FROM = "the Klassroom (yabowzr://klassroom, asked by " + (prevFrom || "the owner") + ")";
        if (typeof window.ROS_SEND === "function") Promise.resolve(window.ROS_SEND(A.ask)).finally(() => { window.ROS_HEART_FROM = prevFrom; });
      }
      else bridgeAct(A.rid, A.action, "url");
    }
  })();
  document.addEventListener("visibilitychange", () => { if (!document.hidden) live(); });
  window.ROS_SHOW_CHATS = showList;
})();
