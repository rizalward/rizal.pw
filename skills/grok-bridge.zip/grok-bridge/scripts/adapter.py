#!/usr/bin/env python3
"""RBOT RBWR adapter. Local plate state, optional public bridge call."""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

HOME = Path(os.environ.get("GROK_BRIDGE_STATE", Path.home() / ".grok-bridge"))
STATE = HOME / "plate.json"
LOG = HOME / "lane.log"
VERBS = ("ping", "handoff", "recall", "stealth", "status")
REFUSED = ("restore", "erase", "usb", "heart-swap", "apply", "publish", "sign", "trash")


def load():
    if STATE.exists():
        return json.loads(STATE.read_text())
    return {
        "mark": "unarmed",
        "plate": 80,
        "lane": "yabot",
        "lanes": {"yabot": "ЯBOT", "yabowzr": "ЯBOWZR"},
        "decider": "this seat",
        "ios": "paused",
    }


def save(state):
    HOME.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(state, indent=2) + "\n")


def call(url, token, verb):
    if not token:
        raise SystemExit("refused: no token")
    req = urllib.request.Request(
        url.rstrip("/") + "/" + verb,
        data=json.dumps({"verb": verb, "plate": 80}).encode(),
        headers={"Authorization": "Bearer " + token, "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("verb", choices=VERBS)
    parser.add_argument("--url", default=os.environ.get("GROK_BRIDGE_URL", ""))
    parser.add_argument("--arm", action="store_true")
    args = parser.parse_args()
    if args.verb in REFUSED:
        raise SystemExit("refused")
    state = load()
    remote = None
    if args.url:
        token = os.environ.get("GROK_BRIDGE_TOKEN", "")
        try:
            remote = call(args.url, token, args.verb)
        except urllib.error.URLError as exc:
            print(json.dumps({"ok": False, "verb": args.verb, "error": str(exc)}))
            return 1
    if args.arm:
        state["mark"] = "Live"
    if args.verb == "handoff":
        state["lane"] = "yabowzr"
    elif args.verb == "recall":
        state["lane"] = "yabot"
    elif args.verb == "stealth" and LOG.exists():
        LOG.write_text("")
    save(state)
    out = {
        "ok": True,
        "verb": args.verb,
        "mark": state["mark"],
        "plate": state["plate"],
        "lane": state["lane"],
        "tunnel": "open" if args.url else "closed",
        "remote": remote,
        "ios": "paused",
    }
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
