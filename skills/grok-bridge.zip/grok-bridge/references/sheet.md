---
description: "Neo proof and refusals for grok.bridge. Read before scoring a Live mark."
---

# Sheet

Neo proof, 2026-10-06 22:06 MT: plate 80 started on ЯBOT, handoff moved it to ЯBOWZR, recall brought it home. Both hearts answered 4 with heart=real. A request with no token was refused. link then arm grok.bridge switched the mark to Live.

Not yet delivered to this chat: the public address, and ping / handoff / recall through that address.

Mac builds still building at that report: ЯBOWZR 1.2.3, ЯBOT 0.3.10. Appcast only if they pass. Face ID approval is in iOS source and is not compiled. Mac keeps the Rlauncher password flow.
