---
name: grok-bridge
description: "Official Super Grok connector skill for the RBOT workshop lane and the RBWR shell lane. Use when linking Grok Bridge, arming grok.bridge, pinging, handing off plate 80, recalling it, redacting the lane log, or reading bridge status. Not for iOS installs, appcast publish, restore, or erase."
type: tool
lifecycle: active
---

# grok.bridge — RBOT RBWR connector

Bridge joins the ЯBOT workshop lane to the ЯBOWZR shell lane. Arm only after Grok Bridge is linked. The Decider mark stays on this seat.

## Seats

| Lane | App | Mouth | Plate home |
|---|---|---|---|
| RBOT | ЯBOT | `yabot` | Plate 80 starts here |
| RBWR | ЯBOWZR | `yabowzr` | Handoff target |

Roster ids already seated: Rizal `ЯID-0001-3QQS`, ЯBOT `ЯID-0002-PQ2Q`, SCOUT `ЯID-0005-KM02`. ЯMAX and ЯBAT are joined. WILD SCOUT BOT has no status.

## Permanent address

- **Catalog (permanent):** `https://rizal.info/botlatch/bridge/` (also `endpoint.json`, potlatch, `/skills/connectors.json`)
- **Live endpoint (permanent):** `https://rizals-macbook-neo.taile78ba8.ts.net` (Tailscale Funnel -> Neo `127.0.0.1:4872`) — `POST /v1/grok-bridge/{ping|handoff|recall|stealth|status}` with Bearer token (401 without)
- GitHub Pages is static HTTPS only; it cannot proxy to Neo. Decider has no Cloudflare account, so there is no named tunnel or Worker reverse proxy.
- **Backups:** RDNS `https://bridge.rizal.info:8443` (rtailscale, pending router port-forward); trycloudflare quick tunnel is **deprecated** (see `connector.json` → `deprecated_public`).

## Arm

1. Confirm the permanent catalog address above. The only public live URL is the Funnel address above; do not invent others.
2. Link Grok Bridge.
3. Arm `grok.bridge`. The mark switches to Live only after arm succeeds.
4. Token stays on Neo. A call with no token must be refused. Never paste a token into chat.
5. Unauthenticated live calls return 401.

## Verbs

Run `scripts/adapter.py`. Pass `--url` only when a Decider-approved public hop has been delivered (temporary tunnel or future durable host). Adapter posts to `<url>/<verb>`; the Neo bridge also serves `/v1/grok-bridge/<verb>`.

| Verb | Does |
|---|---|
| `ping` | Asks both mouths. Pass is `heart=real` from each. |
| `handoff` | Moves plate 80 from `yabot` to `yabowzr`. |
| `recall` | Brings plate 80 back to `yabot`. |
| `stealth` | Redacts the lane log. |
| `status` | Reads mark, plate, and lanes. |

Proof order: `ping`, then `handoff`, then `recall`. A number check is the average of 2, 4, and 6. Pass is `4` with `heart=real` from both. A typed reply file is not a pass.

## Refusals

Refuse restore, erase, USB ownership, the iPhone 14 Pro, Heart swap, apply, publish, sign, and trash. iOS stays paused. Appcast ships only Mac builds that passed. ЯBOWZR 1.2.3 and ЯBOT 0.3.10 are not on the feed until they pass.

## Adapter

```bash
python3 scripts/adapter.py status
python3 scripts/adapter.py ping
python3 scripts/adapter.py handoff
python3 scripts/adapter.py recall
python3 scripts/adapter.py stealth
```

Without `--url`, the adapter keeps local plate state and reports `tunnel=closed`. It must not fabricate a Live group. See `references/sheet.md` for the proof that already passed on Neo.
