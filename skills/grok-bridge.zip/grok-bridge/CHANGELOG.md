# Changelog

## 2026-10-07
- Live endpoint is now the permanent Tailscale Funnel URL https://rizals-macbook-neo.taile78ba8.ts.net (-> 127.0.0.1:4872, Bearer auth). trycloudflare deprecated (backup). RDNS bridge.rizal.info:8443 backup pending router forward.

## 2026-10-06
- Permanent catalog endpoint set to https://rizal.info/botlatch/bridge/ (GitHub Pages). Live path remains Neo 127.0.0.1:4872 with Bearer auth. trycloudflare hop labeled temporary (no Cloudflare account for named tunnels).
- Official grok.bridge skill and RBOT RBWR adapter. Five verbs, plate 80, token refusal, iOS paused.
- Connector manifest: permanent catalog + temporary public hop fields.
